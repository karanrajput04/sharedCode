package com.swift.translator.unit.parser;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.canonical.PartyRole;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.engine.parser.MxMessageParser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for MX message parser.
 */
class MxMessageParserTest {

    private MxMessageParser parser;
    private MessageMetadata metadata;

    @BeforeEach
    void setUp() {
        parser = new MxMessageParser();
        metadata = MessageMetadata.builder()
            .correlationId("test-correlation-id")
            .build();
    }

    @Test
    void shouldSupportMxMessageType() {
        assertThat(parser.supports(MessageType.of("pacs.008.001.08"))).isTrue();
        assertThat(parser.supports(MessageType.of("MT103"))).isFalse();
    }

    @Test
    void shouldParsePacs008Message() {
        String pacs008 = buildSamplePacs008();

        CanonicalMessage result = parser.parse(pacs008, MessageType.of("pacs.008.001.08"), metadata);

        assertThat(result).isNotNull();
        assertThat(result.getHeader()).isNotNull();
        assertThat(result.getHeader().getMessageId()).isEqualTo("MSG-20230615-001");
    }

    @Test
    void shouldParsePartiesFromPacs008() {
        String pacs008 = buildSamplePacs008();

        CanonicalMessage result = parser.parse(pacs008, MessageType.of("pacs.008.001.08"), metadata);

        assertThat(result.getParties()).isNotEmpty();
        assertThat(result.getPartyByRole(PartyRole.DEBTOR)).isPresent();
        assertThat(result.getPartyByRole(PartyRole.CREDITOR)).isPresent();
    }

    @Test
    void shouldParseAmountsFromPacs008() {
        String pacs008 = buildSamplePacs008();

        CanonicalMessage result = parser.parse(pacs008, MessageType.of("pacs.008.001.08"), metadata);

        assertThat(result.getAmounts()).isNotEmpty();
        assertThat(result.getInstructedAmount()).isPresent();
    }

    @Test
    void shouldReturnMxFormat() {
        assertThat(parser.getFormat()).isEqualTo("MX");
    }

    private String buildSamplePacs008() {
        return "<?xml version="1.0" encoding="UTF-8"?>
" +
            "<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08">
" +
            "  <FIToFICstmrCdtTrf>
" +
            "    <GrpHdr>
" +
            "      <MsgId>MSG-20230615-001</MsgId>
" +
            "      <CreDtTm>2023-06-15T10:30:00</CreDtTm>
" +
            "      <NbOfTxs>1</NbOfTxs>
" +
            "      <SttlmInf>
" +
            "        <SttlmMtd>INDA</SttlmMtd>
" +
            "      </SttlmInf>
" +
            "      <InstgAgt>
" +
            "        <FinInstnId>
" +
            "          <BICFI>CHASUS33</BICFI>
" +
            "        </FinInstnId>
" +
            "      </InstgAgt>
" +
            "      <InstdAgt>
" +
            "        <FinInstnId>
" +
            "          <BICFI>BANKDEFF</BICFI>
" +
            "        </FinInstnId>
" +
            "      </InstdAgt>
" +
            "    </GrpHdr>
" +
            "    <CdtTrfTxInf>
" +
            "      <PmtId>
" +
            "        <InstrId>INSTRUCTION001</InstrId>
" +
            "        <EndToEndId>E2E-001</EndToEndId>
" +
            "        <TxId>TX-001</TxId>
" +
            "      </PmtId>
" +
            "      <IntrBkSttlmAmt Ccy="USD">100000.00</IntrBkSttlmAmt>
" +
            "      <IntrBkSttlmDt>2023-06-15</IntrBkSttlmDt>
" +
            "      <ChrgBr>SHAR</ChrgBr>
" +
            "      <Dbtr>
" +
            "        <Nm>JOHN DOE</Nm>
" +
            "        <PstlAdr>
" +
            "          <AdrLine>123 MAIN STREET</AdrLine>
" +
            "          <Ctry>US</Ctry>
" +
            "        </PstlAdr>
" +
            "      </Dbtr>
" +
            "      <Cdtr>
" +
            "        <Nm>JANE SMITH</Nm>
" +
            "        <PstlAdr>
" +
            "          <AdrLine>456 OAK AVENUE</AdrLine>
" +
            "          <Ctry>GB</Ctry>
" +
            "        </PstlAdr>
" +
            "      </Cdtr>
" +
            "    </CdtTrfTxInf>
" +
            "  </FIToFICstmrCdtTrf>
" +
            "</Document>";
    }
}
