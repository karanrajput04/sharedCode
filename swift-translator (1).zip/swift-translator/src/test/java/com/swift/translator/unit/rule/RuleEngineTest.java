package com.swift.translator.unit.rule;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.canonical.Amount;
import com.swift.translator.domain.model.canonical.AmountType;
import com.swift.translator.domain.model.config.RuleConfiguration;
import com.swift.translator.engine.rule.RuleEngine;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for rule engine.
 */
class RuleEngineTest {

    private RuleEngine ruleEngine;

    @BeforeEach
    void setUp() {
        ruleEngine = new RuleEngine();
    }

    @Test
    void shouldAllowMessageWithNoRules() {
        CanonicalMessage message = CanonicalMessage.builder().build();
        RuleConfiguration config = RuleConfiguration.builder().build();

        RuleEngine.RuleResult result = ruleEngine.evaluate(message, config);

        assertThat(result.allowed()).isTrue();
        assertThat(result.hasViolations()).isFalse();
    }

    @Test
    void shouldBlockMessageMatchingBlockRule() {
        CanonicalMessage message = CanonicalMessage.builder()
            .amounts(Arrays.asList(
                Amount.builder()
                    .type(AmountType.INTERBANK_SETTLEMENT)
                    .value(new BigDecimal("15000000"))
                    .currency("USD")
                    .build()
            ))
            .build();

        RuleConfiguration config = RuleConfiguration.builder()
            .rule(RuleConfiguration.Rule.builder()
                .id("RULE_001")
                .name("Amount Limit")
                .priority(1)
                .condition(RuleConfiguration.Condition.builder()
                    .type("FIELD")
                    .field("amount.INTERBANK_SETTLEMENT.value")
                    .operator("GREATER_THAN")
                    .value("10000000")
                    .build())
                .action("BLOCK")
                .message("Amount exceeds limit")
                .stopOnMatch(true)
                .build())
            .build();

        RuleEngine.RuleResult result = ruleEngine.evaluate(message, config);

        assertThat(result.allowed()).isFalse();
        assertThat(result.hasViolations()).isTrue();
        assertThat(result.violations()).hasSize(1);
    }

    @Test
    void shouldFlagMessageMatchingFlagRule() {
        CanonicalMessage message = CanonicalMessage.builder()
            .amounts(Arrays.asList(
                Amount.builder()
                    .type(AmountType.INTERBANK_SETTLEMENT)
                    .value(new BigDecimal("5000000"))
                    .currency("USD")
                    .build()
            ))
            .build();

        RuleConfiguration config = RuleConfiguration.builder()
            .rule(RuleConfiguration.Rule.builder()
                .id("RULE_001")
                .name("Amount Flag")
                .priority(1)
                .condition(RuleConfiguration.Condition.builder()
                    .type("FIELD")
                    .field("amount.INTERBANK_SETTLEMENT.value")
                    .operator("GREATER_THAN")
                    .value("1000000")
                    .build())
                .action("FLAG")
                .message("High value payment")
                .stopOnMatch(false)
                .build())
            .build();

        RuleEngine.RuleResult result = ruleEngine.evaluate(message, config);

        assertThat(result.allowed()).isTrue();
        assertThat(result.hasViolations()).isFalse();
        assertThat(result.flags()).hasSize(1);
    }

    @Test
    void shouldEvaluateAndConditions() {
        CanonicalMessage message = CanonicalMessage.builder()
            .amounts(Arrays.asList(
                Amount.builder()
                    .type(AmountType.INTERBANK_SETTLEMENT)
                    .value(new BigDecimal("5000000"))
                    .currency("USD")
                    .build()
            ))
            .build();

        RuleConfiguration config = RuleConfiguration.builder()
            .rule(RuleConfiguration.Rule.builder()
                .id("RULE_001")
                .name("And Condition")
                .priority(1)
                .condition(RuleConfiguration.Condition.builder()
                    .type("AND")
                    .conditions(Arrays.asList(
                        RuleConfiguration.Condition.builder()
                            .type("FIELD")
                            .field("amount.INTERBANK_SETTLEMENT.value")
                            .operator("GREATER_THAN")
                            .value("1000000")
                            .build(),
                        RuleConfiguration.Condition.builder()
                            .type("FIELD")
                            .field("amount.INTERBANK_SETTLEMENT.currency")
                            .operator("EQUALS")
                            .value("USD")
                            .build()
                    ))
                    .build())
                .action("FLAG")
                .message("USD high value")
                .build())
            .build();

        RuleEngine.RuleResult result = ruleEngine.evaluate(message, config);

        assertThat(result.flags()).hasSize(1);
    }

    @Test
    void shouldEvaluateOrConditions() {
        CanonicalMessage message = CanonicalMessage.builder()
            .amounts(Arrays.asList(
                Amount.builder()
                    .type(AmountType.INTERBANK_SETTLEMENT)
                    .value(new BigDecimal("500"))
                    .currency("EUR")
                    .build()
            ))
            .build();

        RuleConfiguration config = RuleConfiguration.builder()
            .rule(RuleConfiguration.Rule.builder()
                .id("RULE_001")
                .name("Or Condition")
                .priority(1)
                .condition(RuleConfiguration.Condition.builder()
                    .type("OR")
                    .conditions(Arrays.asList(
                        RuleConfiguration.Condition.builder()
                            .type("FIELD")
                            .field("amount.INTERBANK_SETTLEMENT.value")
                            .operator("GREATER_THAN")
                            .value("1000000")
                            .build(),
                        RuleConfiguration.Condition.builder()
                            .type("FIELD")
                            .field("amount.INTERBANK_SETTLEMENT.currency")
                            .operator("EQUALS")
                            .value("EUR")
                            .build()
                    ))
                    .build())
                .action("FLAG")
                .message("EUR or high value")
                .build())
            .build();

        RuleEngine.RuleResult result = ruleEngine.evaluate(message, config);

        assertThat(result.flags()).hasSize(1);
    }
}
