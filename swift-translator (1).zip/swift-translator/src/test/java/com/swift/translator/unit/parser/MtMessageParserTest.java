package com.swift.translator.unit.parser;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.canonical.PartyRole;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.engine.parser.MtMessageParser;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Unit tests for MT message parser.
 */
class MtMessageParserTest {

    private MtMessageParser parser;
    private MessageMetadata metadata;

    @BeforeEach
    void setUp() {
        parser = new MtMessageParser();
        metadata = MessageMetadata.builder()
            .correlationId("test-correlation-id")
            .build();
    }

    @Test
    void shouldSupportMtMessageType() {
        assertThat(parser.supports(MessageType.of("MT103"))).isTrue();
        assertThat(parser.supports(MessageType.of("MT202"))).isTrue();
        assertThat(parser.supports(MessageType.of("pacs.008.001.08"))).isFalse();
    }

    @Test
    void shouldParseMt103Message() {
        String mt103 = buildSampleMt103();

        CanonicalMessage result = parser.parse(mt103, MessageType.of("MT103"), metadata);

        assertThat(result).isNotNull();
        assertThat(result.getHeader()).isNotNull();
        assertThat(result.getTransaction()).isNotNull();
        assertThat(result.getTransaction().getTransactionReference()).isEqualTo("REFERENCE123");
        assertThat(result.getTransaction().getTransactionType()).isEqualTo("CRED");
    }

    @Test
    void shouldParsePartiesFromMt103() {
        String mt103 = buildSampleMt103();

        CanonicalMessage result = parser.parse(mt103, MessageType.of("MT103"), metadata);

        assertThat(result.getParties()).isNotEmpty();
        assertThat(result.getPartyByRole(PartyRole.ORDERING_CUSTOMER)).isPresent();
        assertThat(result.getPartyByRole(PartyRole.BENEFICIARY)).isPresent();
    }

    @Test
    void shouldParseAmountsFromMt103() {
        String mt103 = buildSampleMt103();

        CanonicalMessage result = parser.parse(mt103, MessageType.of("MT103"), metadata);

        assertThat(result.getAmounts()).isNotEmpty();
        assertThat(result.getInstructedAmount()).isPresent();
    }

    @Test
    void shouldThrowExceptionForInvalidMtMessage() {
        String invalidMessage = "INVALID MESSAGE CONTENT";

        assertThatThrownBy(() -> parser.parse(invalidMessage, MessageType.of("MT103"), metadata))
            .isInstanceOf(com.swift.translator.domain.exception.ParsingException.class)
            .hasMessageContaining("Failed to parse MT message");
    }

    @Test
    void shouldReturnMtFormat() {
        assertThat(parser.getFormat()).isEqualTo("MT");
    }

    private String buildSampleMt103() {
        return "{1:F01CHASUS33AXXX0000000000}{2:I103BANKDEFFXXXXN}{4:
" +
            ":20:REFERENCE123
" +
            ":23B:CRED
" +
            ":32A:230615USD100000,00
" +
            ":50K:/123456789
" +
            "JOHN DOE
" +
            "123 MAIN STREET
" +
            "NEW YORK
" +
            ":59:/987654321
" +
            "JANE SMITH
" +
            "456 OAK AVENUE
" +
            "LONDON
" +
            ":71A:SHA
" +
            "-}";
    }
}
