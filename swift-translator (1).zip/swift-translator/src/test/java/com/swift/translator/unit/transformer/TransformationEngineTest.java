package com.swift.translator.unit.transformer;

import com.swift.translator.engine.transformer.FunctionRegistry;
import com.swift.translator.engine.transformer.TransformationEngine;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit tests for transformation engine.
 */
class TransformationEngineTest {

    private TransformationEngine engine;

    @BeforeEach
    void setUp() {
        FunctionRegistry registry = new FunctionRegistry();
        engine = new TransformationEngine(registry);
    }

    @Test
    void shouldApplyUppercaseTransformation() {
        String result = (String) engine.transform("hello", "uppercase(value)");
        assertThat(result).isEqualTo("HELLO");
    }

    @Test
    void shouldApplyLowercaseTransformation() {
        String result = (String) engine.transform("HELLO", "lowercase(value)");
        assertThat(result).isEqualTo("hello");
    }

    @Test
    void shouldApplyTrimTransformation() {
        String result = (String) engine.transform("  hello  ", "trim(value)");
        assertThat(result).isEqualTo("hello");
    }

    @Test
    void shouldApplySubstringTransformation() {
        String result = (String) engine.transform("hello world", "substring(value, 0, 5)");
        assertThat(result).isEqualTo("hello");
    }

    @Test
    void shouldApplyConcatenateTransformation() {
        String result = (String) engine.transform("hello", "concatenate(value, ' world')");
        assertThat(result).isEqualTo("hello world");
    }

    @Test
    void shouldApplyReplaceTransformation() {
        String result = (String) engine.transform("hello world", "replace(value, 'world', 'universe')");
        assertThat(result).isEqualTo("hello universe");
    }

    @Test
    void shouldApplyDateConversion() {
        String result = (String) engine.transform("230615", "dateConvert(value, 'yyMMdd', 'yyyy-MM-dd')");
        assertThat(result).isEqualTo("2023-06-15");
    }

    @Test
    void shouldReturnOriginalOnNullExpression() {
        String result = (String) engine.transform("hello", null);
        assertThat(result).isEqualTo("hello");
    }

    @Test
    void shouldReturnOriginalOnEmptyExpression() {
        String result = (String) engine.transform("hello", "");
        assertThat(result).isEqualTo("hello");
    }

    @Test
    void shouldApplyTransformationChain() {
        List<String> expressions = Arrays.asList(
            "trim(value)",
            "uppercase(value)"
        );
        String result = (String) engine.transformChain("  hello  ", expressions);
        assertThat(result).isEqualTo("HELLO");
    }
}
