package com.swift.translator.integration;

import com.swift.translator.SwiftTranslatorApplication;
import com.swift.translator.api.dto.TranslationRequest;
import com.swift.translator.api.dto.TranslationResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integration tests for the translation API.
 */
@SpringBootTest(classes = SwiftTranslatorApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class TranslationFlowTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void shouldTranslateMt103ToPacs008() {
        String mt103 = buildSampleMt103();

        TranslationRequest request = TranslationRequest.builder()
            .message(mt103)
            .sourceType("MT103")
            .targetType("pacs.008.001.08")
            .build();

        ResponseEntity<TranslationResponse> response = restTemplate.postForEntity(
            "http://localhost:" + port + "/api/v1/translate",
            request,
            TranslationResponse.class
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getOutput()).isNotEmpty();
        assertThat(response.getBody().getSourceType()).isEqualTo("MT103");
        assertThat(response.getBody().getTargetType()).isEqualTo("pacs.008.001.08");
        assertThat(response.getBody().isSuccess()).isTrue();
    }

    @Test
    void shouldTranslatePacs008ToMt103() {
        String pacs008 = buildSamplePacs008();

        TranslationRequest request = TranslationRequest.builder()
            .message(pacs008)
            .sourceType("pacs.008.001.08")
            .targetType("MT103")
            .build();

        ResponseEntity<TranslationResponse> response = restTemplate.postForEntity(
            "http://localhost:" + port + "/api/v1/translate",
            request,
            TranslationResponse.class
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getOutput()).isNotEmpty();
        assertThat(response.getBody().getSourceType()).isEqualTo("pacs.008.001.08");
        assertThat(response.getBody().getTargetType()).isEqualTo("MT103");
    }

    @Test
    void shouldAutoDetectSourceType() {
        String mt103 = buildSampleMt103();

        TranslationRequest request = TranslationRequest.builder()
            .message(mt103)
            .targetType("pacs.008.001.08")
            .build();

        ResponseEntity<TranslationResponse> response = restTemplate.postForEntity(
            "http://localhost:" + port + "/api/v1/translate",
            request,
            TranslationResponse.class
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
    }

    @Test
    void shouldReturnCorrelationId() {
        String mt103 = buildSampleMt103();
        String correlationId = "test-correlation-123";

        TranslationRequest request = TranslationRequest.builder()
            .message(mt103)
            .sourceType("MT103")
            .targetType("pacs.008.001.08")
            .build();

        org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
        headers.set("X-Correlation-Id", correlationId);

        org.springframework.http.HttpEntity<TranslationRequest> entity = 
            new org.springframework.http.HttpEntity<>(request, headers);

        ResponseEntity<TranslationResponse> response = restTemplate.postForEntity(
            "http://localhost:" + port + "/api/v1/translate",
            entity,
            TranslationResponse.class
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getCorrelationId()).isEqualTo(correlationId);
        assertThat(response.getHeaders().getFirst("X-Correlation-Id")).isEqualTo(correlationId);
    }

    private String buildSampleMt103() {
        return "{1:F01CHASUS33AXXX0000000000}{2:I103BANKDEFFXXXXN}{4:
" +
            ":20:REFERENCE123
" +
            ":23B:CRED
" +
            ":32A:230615USD100000,00
" +
            ":50K:/123456789
" +
            "JOHN DOE
" +
            "123 MAIN STREET
" +
            "NEW YORK
" +
            ":59:/987654321
" +
            "JANE SMITH
" +
            "456 OAK AVENUE
" +
            "LONDON
" +
            ":71A:SHA
" +
            "-}";
    }

    private String buildSamplePacs008() {
        return "<?xml version="1.0" encoding="UTF-8"?>
" +
            "<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.08">
" +
            "  <FIToFICstmrCdtTrf>
" +
            "    <GrpHdr>
" +
            "      <MsgId>MSG-20230615-001</MsgId>
" +
            "      <CreDtTm>2023-06-15T10:30:00</CreDtTm>
" +
            "      <NbOfTxs>1</NbOfTxs>
" +
            "      <SttlmInf>
" +
            "        <SttlmMtd>INDA</SttlmMtd>
" +
            "      </SttlmInf>
" +
            "    </GrpHdr>
" +
            "    <CdtTrfTxInf>
" +
            "      <PmtId>
" +
            "        <InstrId>INSTRUCTION001</InstrId>
" +
            "        <EndToEndId>E2E-001</EndToEndId>
" +
            "        <TxId>TX-001</TxId>
" +
            "      </PmtId>
" +
            "      <IntrBkSttlmAmt Ccy="USD">100000.00</IntrBkSttlmAmt>
" +
            "      <IntrBkSttlmDt>2023-06-15</IntrBkSttlmDt>
" +
            "      <ChrgBr>SHAR</ChrgBr>
" +
            "      <Dbtr>
" +
            "        <Nm>JOHN DOE</Nm>
" +
            "      </Dbtr>
" +
            "      <Cdtr>
" +
            "        <Nm>JANE SMITH</Nm>
" +
            "      </Cdtr>
" +
            "    </CdtTrfTxInf>
" +
            "  </FIToFICstmrCdtTrf>
" +
            "</Document>";
    }
}
