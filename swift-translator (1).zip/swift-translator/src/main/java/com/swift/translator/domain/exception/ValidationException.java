package com.swift.translator.domain.exception;

import com.swift.translator.domain.model.message.MessageMetadata;
import lombok.Getter;

import java.util.Collections;
import java.util.List;

/**
 * Exception thrown when message validation fails.
 * 
 * <p>Contains a list of validation errors for comprehensive reporting.</p>
 */
@Getter
public class ValidationException extends TranslationException {

    private final List<ValidationError> errors;

    public ValidationException(String message, List<ValidationError> errors, 
                               String errorCode, MessageMetadata metadata) {
        super(message, errorCode, metadata);
        this.errors = errors != null ? Collections.unmodifiableList(errors) : Collections.emptyList();
    }

    public boolean hasErrors() {
        return !errors.isEmpty();
    }

    /**
     * Individual validation error record.
     */
    @Getter
    public static class ValidationError {
        private final String field;
        private final String errorCode;
        private final String message;
        private final String severity; // ERROR, WARNING

        public ValidationError(String field, String errorCode, String message, String severity) {
            this.field = field;
            this.errorCode = errorCode;
            this.message = message;
            this.severity = severity;
        }

        public ValidationError(String field, String errorCode, String message) {
            this(field, errorCode, message, "ERROR");
        }
    }
}
