package com.swift.translator.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * JSON utility methods.
 */
public final class JsonUtils {

    private JsonUtils() {
        // Utility class
    }

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public static JsonNode parseJson(String json) throws Exception {
        return OBJECT_MAPPER.readTree(json);
    }

    public static String toJson(Object obj) throws Exception {
        return OBJECT_MAPPER.writeValueAsString(obj);
    }

    public static String getValue(JsonNode node, String path) {
        String[] parts = path.split("\.");
        JsonNode current = node;
        for (String part : parts) {
            if (current == null) return null;
            current = current.get(part);
        }
        return current != null ? current.asText() : null;
    }
}
