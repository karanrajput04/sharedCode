package com.swift.translator.engine.serializer;

import com.swift.translator.domain.model.canonical.*;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ParsingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * Serializer for ISO 20022 MX (XML) messages.
 * 
 * <p>Converts canonical model to ISO 20022 XML format.</p>
 */
@Slf4j
@Component
public class MxMessageSerializer implements MessageSerializer {

    private static final DateTimeFormatter ISO_DATETIME_FORMAT = DateTimeFormatter.ISO_DATE_TIME;
    private static final String ISO20022_NS = "urn:iso:std:iso:20022:tech:xsd:";

    private final DocumentBuilderFactory docBuilderFactory;
    private final TransformerFactory transformerFactory;

    public MxMessageSerializer() {
        this.docBuilderFactory = DocumentBuilderFactory.newInstance();
        this.docBuilderFactory.setNamespaceAware(true);
        this.transformerFactory = TransformerFactory.newInstance();
    }

    @Override
    public boolean supports(MessageType messageType) {
        return messageType != null && messageType.isMx();
    }

    @Override
    public String serialize(CanonicalMessage canonicalMessage, MessageType targetType, MessageMetadata metadata) {
        log.debug("Serializing to MX message type: {}, correlationId: {}", targetType.getTypeCode(), metadata.getCorrelationId());

        try {
            DocumentBuilder builder = docBuilderFactory.newDocumentBuilder();
            Document doc = builder.newDocument();

            String ns = ISO20022_NS + targetType.getTypeCode();

            Element documentElement = doc.createElementNS(ns, "Document");
            doc.appendChild(documentElement);

            if (targetType.getTypeCode().startsWith("pacs.008")) {
                buildPacs008(doc, documentElement, canonicalMessage, targetType);
            } else if (targetType.getTypeCode().startsWith("pacs.009")) {
                buildPacs009(doc, documentElement, canonicalMessage, targetType);
            } else {
                buildGenericMx(doc, documentElement, canonicalMessage, targetType);
            }

            return transformToString(doc);

        } catch (Exception e) {
            throw new ParsingException("Failed to serialize MX message: " + e.getMessage(), e,
                "MX_SERIALIZE_ERROR", metadata);
        }
    }

    private void buildPacs008(Document doc, Element root, CanonicalMessage msg, MessageType targetType) {
        String ns = ISO20022_NS + targetType.getTypeCode();

        Element fiToFICstmrCdtTrf = doc.createElementNS(ns, "FIToFICstmrCdtTrf");
        root.appendChild(fiToFICstmrCdtTrf);

        Element grpHdr = doc.createElementNS(ns, "GrpHdr");
        fiToFICstmrCdtTrf.appendChild(grpHdr);

        String msgId = msg.getHeader() != null && msg.getHeader().getMessageId() != null 
            ? msg.getHeader().getMessageId() 
            : UUID.randomUUID().toString();
        grpHdr.appendChild(createElement(doc, ns, "MsgId", msgId));

        String creDtTm = msg.getHeader() != null && msg.getHeader().getCreationDateTime() != null
            ? msg.getHeader().getCreationDateTime().format(ISO_DATETIME_FORMAT)
            : LocalDateTime.now().format(ISO_DATETIME_FORMAT);
        grpHdr.appendChild(createElement(doc, ns, "CreDtTm", creDtTm));

        grpHdr.appendChild(createElement(doc, ns, "NbOfTxs", "1"));

        Element sttlmInf = doc.createElementNS(ns, "SttlmInf");
        sttlmInf.appendChild(createElement(doc, ns, "SttlmMtd", "INDA"));
        grpHdr.appendChild(sttlmInf);

        if (msg.getHeader() != null && msg.getHeader().getSenderBic() != null) {
            grpHdr.appendChild(createAgent(doc, ns, "InstgAgt", msg.getHeader().getSenderBic()));
        }

        if (msg.getHeader() != null && msg.getHeader().getReceiverBic() != null) {
            grpHdr.appendChild(createAgent(doc, ns, "InstdAgt", msg.getHeader().getReceiverBic()));
        }

        Element cdtTrfTxInf = doc.createElementNS(ns, "CdtTrfTxInf");
        fiToFICstmrCdtTrf.appendChild(cdtTrfTxInf);

        Element pmtId = doc.createElementNS(ns, "PmtId");
        cdtTrfTxInf.appendChild(pmtId);

        if (msg.getTransaction() != null && msg.getTransaction().getTransactionReference() != null) {
            pmtId.appendChild(createElement(doc, ns, "InstrId", msg.getTransaction().getTransactionReference()));
        }
        if (msg.getTransaction() != null && msg.getTransaction().getRelatedReference() != null) {
            pmtId.appendChild(createElement(doc, ns, "EndToEndId", msg.getTransaction().getRelatedReference()));
        }
        pmtId.appendChild(createElement(doc, ns, "TxId", UUID.randomUUID().toString()));
        pmtId.appendChild(createElement(doc, ns, "UETR", UUID.randomUUID().toString()));

        msg.getInstructedAmount().ifPresent(amount -> {
            Element intrBkSttlmAmt = doc.createElementNS(ns, "IntrBkSttlmAmt");
            intrBkSttlmAmt.setAttribute("Ccy", amount.getCurrency());
            intrBkSttlmAmt.setTextContent(amount.getValue().toPlainString());
            cdtTrfTxInf.appendChild(intrBkSttlmAmt);
        });

        if (msg.getTransaction() != null && msg.getTransaction().getValueDate() != null) {
            cdtTrfTxInf.appendChild(createElement(doc, ns, "IntrBkSttlmDt", 
                msg.getTransaction().getValueDate().toString()));
        }

        if (msg.getTransaction() != null && msg.getTransaction().getChargeBearer() != null) {
            String chrgBr = mapChargeBearerToMx(msg.getTransaction().getChargeBearer());
            cdtTrfTxInf.appendChild(createElement(doc, ns, "ChrgBr", chrgBr));
        }

        msg.getPartyByRole(PartyRole.ORDERING_CUSTOMER).ifPresent(party -> 
            cdtTrfTxInf.appendChild(createParty(doc, ns, "Dbtr", party)));

        msg.getPartyByRole(PartyRole.DEBTOR_AGENT).ifPresent(party -> 
            cdtTrfTxInf.appendChild(createAgent(doc, ns, "DbtrAgt", party.getBicfi())));

        msg.getPartyByRole(PartyRole.CREDITOR_AGENT).ifPresent(party -> 
            cdtTrfTxInf.appendChild(createAgent(doc, ns, "CdtrAgt", party.getBicfi())));

        msg.getPartyByRole(PartyRole.BENEFICIARY).ifPresent(party -> 
            cdtTrfTxInf.appendChild(createParty(doc, ns, "Cdtr", party)));

        if (msg.getNarratives() != null && !msg.getNarratives().isEmpty()) {
            Element rmtInf = doc.createElementNS(ns, "RmtInf");
            for (Narrative narrative : msg.getNarratives()) {
                if (narrative.getFullText() != null) {
                    rmtInf.appendChild(createElement(doc, ns, "Ustrd", narrative.getFullText()));
                }
            }
            if (rmtInf.hasChildNodes()) {
                cdtTrfTxInf.appendChild(rmtInf);
            }
        }
    }

    private void buildPacs009(Document doc, Element root, CanonicalMessage msg, MessageType targetType) {
        buildGenericMx(doc, root, msg, targetType);
    }

    private void buildGenericMx(Document doc, Element root, CanonicalMessage msg, MessageType targetType) {
        String ns = ISO20022_NS + targetType.getTypeCode();
        Element grpHdr = doc.createElementNS(ns, "GrpHdr");
        root.appendChild(grpHdr);
        grpHdr.appendChild(createElement(doc, ns, "MsgId", UUID.randomUUID().toString()));
        grpHdr.appendChild(createElement(doc, ns, "CreDtTm", LocalDateTime.now().format(ISO_DATETIME_FORMAT)));
        grpHdr.appendChild(createElement(doc, ns, "NbOfTxs", "1"));
    }

    private Element createElement(Document doc, String ns, String name, String value) {
        Element element = doc.createElementNS(ns, name);
        if (value != null) {
            element.setTextContent(value);
        }
        return element;
    }

    private Element createAgent(Document doc, String ns, String name, String bicfi) {
        Element agent = doc.createElementNS(ns, name);
        Element finInstnId = doc.createElementNS(ns, "FinInstnId");
        finInstnId.appendChild(createElement(doc, ns, "BICFI", bicfi));
        agent.appendChild(finInstnId);
        return agent;
    }

    private Element createParty(Document doc, String ns, String name, Party party) {
        Element partyElement = doc.createElementNS(ns, name);

        if (party.getName() != null) {
            partyElement.appendChild(createElement(doc, ns, "Nm", party.getName()));
        }

        if (party.getAddress() != null || party.getCity() != null || party.getCountry() != null) {
            Element pstlAdr = doc.createElementNS(ns, "PstlAdr");
            if (party.getAddress() != null) {
                pstlAdr.appendChild(createElement(doc, ns, "AdrLine", party.getAddress()));
            }
            if (party.getCity() != null) {
                pstlAdr.appendChild(createElement(doc, ns, "TwnNm", party.getCity()));
            }
            if (party.getCountry() != null) {
                pstlAdr.appendChild(createElement(doc, ns, "Ctry", party.getCountry()));
            }
            partyElement.appendChild(pstlAdr);
        }

        if (party.getAccountNumber() != null) {
            Element acct = doc.createElementNS(ns, "Acct");
            Element id = doc.createElementNS(ns, "Id");
            Element othr = doc.createElementNS(ns, "Othr");
            othr.appendChild(createElement(doc, ns, "Id", party.getAccountNumber()));
            id.appendChild(othr);
            acct.appendChild(id);
            partyElement.appendChild(acct);
        }

        return partyElement;
    }

    private String mapChargeBearerToMx(String mtChargeBearer) {
        return switch (mtChargeBearer) {
            case "BEN" -> "CRED";
            case "SHA" -> "SHAR";
            case "OUR" -> "DEBT";
            default -> "SLEV";
        };
    }

    private String transformToString(Document doc) throws Exception {
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

        StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(doc), new StreamResult(writer));
        return writer.toString();
    }

    @Override
    public String getFormat() {
        return "MX";
    }
}
