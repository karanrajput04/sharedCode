package com.swift.translator.api.controller;

import com.swift.translator.api.dto.TranslationRequest;
import com.swift.translator.api.dto.TranslationResponse;
import com.swift.translator.api.dto.ErrorResponse;
import com.swift.translator.application.port.inbound.TranslateMessageUseCase;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.TranslationException;
import com.swift.translator.domain.exception.ValidationException;
import com.swift.translator.domain.exception.ParsingException;
import com.swift.translator.domain.exception.MappingException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.UUID;

/**
 * REST API controller for message translation operations.
 * 
 * <p>Provides endpoints for:
 * <ul>
 *   <li>Single message translation (sync)</li>
 *   <li>Batch translation (async)</li>
 *   <li>Message format detection</li>
 *   <li>Supported message types</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/translate")
@RequiredArgsConstructor
public class TranslationController {

    private final TranslateMessageUseCase translationUseCase;

    /**
     * Translates a single message from source format to target format.
     * 
     * @param request translation request containing message and type information
     * @param correlationId optional correlation ID for tracing
     * @return translated message with metadata
     */
    @PostMapping
    public ResponseEntity<TranslationResponse> translate(
            @Valid @RequestBody TranslationRequest request,
            @RequestHeader(value = "X-Correlation-Id", required = false) String correlationId,
            @RequestHeader(value = "X-Message-Id", required = false) String messageId) {

        String corrId = correlationId != null && !correlationId.isEmpty() 
            ? correlationId 
            : UUID.randomUUID().toString();

        log.info("Translation request received: {} -> {}, correlationId: {}",
            request.getSourceType(), request.getTargetType(), corrId);

        MessageMetadata metadata = MessageMetadata.builder()
            .correlationId(corrId)
            .messageId(messageId != null ? messageId : request.getMessageId())
            .build();

        MessageType sourceType = request.getSourceType() != null && !request.getSourceType().isEmpty()
            ? MessageType.of(request.getSourceType())
            : null;
        MessageType targetType = MessageType.of(request.getTargetType());

        TranslateMessageUseCase.TranslationResult result;

        if (sourceType != null) {
            result = translationUseCase.translate(request.getMessage(), sourceType, targetType, metadata);
        } else {
            result = translationUseCase.translate(request.getMessage(), targetType, metadata);
        }

        TranslationResponse response = TranslationResponse.builder()
            .correlationId(corrId)
            .output(result.output())
            .sourceType(result.sourceType().getTypeCode())
            .targetType(result.targetType().getTypeCode())
            .processingTimeMs(result.processingTimeMs())
            .success(result.success())
            .warnings(result.warnings())
            .timestamp(Instant.now().toString())
            .build();

        log.info("Translation response sent, correlationId: {}, processingTimeMs: {}",
            corrId, result.processingTimeMs());

        return ResponseEntity.ok(response);
    }

    /**
     * Detects the message format and type from raw content.
     */
    @PostMapping("/detect")
    public ResponseEntity<com.swift.translator.api.dto.DetectionResponse> detect(
            @RequestBody String rawMessage,
            @RequestHeader(value = "X-Correlation-Id", required = false) String correlationId) {

        String corrId = correlationId != null ? correlationId : UUID.randomUUID().toString();
        log.info("Detection request received, correlationId: {}", corrId);

        // Detection logic would be injected here
        return ResponseEntity.ok(com.swift.translator.api.dto.DetectionResponse.builder()
            .correlationId(corrId)
            .detectedType("MT103")
            .confidence(0.95)
            .build());
    }

    @ExceptionHandler(ParsingException.class)
    public ResponseEntity<ErrorResponse> handleParsingException(ParsingException e) {
        log.error("Parsing error: {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            .body(ErrorResponse.builder()
                .errorCode(e.getErrorCode())
                .message(e.getMessage())
                .correlationId(e.getCorrelationId())
                .timestamp(Instant.now().toString())
                .build());
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(ValidationException e) {
        log.error("Validation error: {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY)
            .body(ErrorResponse.builder()
                .errorCode(e.getErrorCode())
                .message(e.getMessage())
                .correlationId(e.getCorrelationId())
                .validationErrors(e.getErrors())
                .timestamp(Instant.now().toString())
                .build());
    }

    @ExceptionHandler(MappingException.class)
    public ResponseEntity<ErrorResponse> handleMappingException(MappingException e) {
        log.error("Mapping error: {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY)
            .body(ErrorResponse.builder()
                .errorCode(e.getErrorCode())
                .message(e.getMessage())
                .correlationId(e.getCorrelationId())
                .timestamp(Instant.now().toString())
                .build());
    }

    @ExceptionHandler(TranslationException.class)
    public ResponseEntity<ErrorResponse> handleTranslationException(TranslationException e) {
        log.error("Translation error: {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(ErrorResponse.builder()
                .errorCode(e.getErrorCode())
                .message(e.getMessage())
                .correlationId(e.getCorrelationId())
                .timestamp(Instant.now().toString())
                .build());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(Exception e) {
        log.error("Unexpected error: {}", e.getMessage(), e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(ErrorResponse.builder()
                .errorCode("INTERNAL_ERROR")
                .message("An unexpected error occurred: " + e.getMessage())
                .timestamp(Instant.now().toString())
                .build());
    }
}
