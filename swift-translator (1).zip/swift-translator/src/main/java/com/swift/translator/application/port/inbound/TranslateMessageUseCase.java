package com.swift.translator.application.port.inbound;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;

/**
 * Primary port (use case) for translating messages.
 * 
 * <p>Defines the contract that the application layer exposes to inbound adapters.</p>
 */
public interface TranslateMessageUseCase {

    /**
     * Translates a message from source format to target format.
     * 
     * @param rawMessage the raw message content
     * @param sourceType the detected or specified source message type
     * @param targetType the desired target message type
     * @param metadata message metadata including correlation ID
     * @return translation result containing output and metadata
     */
    TranslationResult translate(String rawMessage, MessageType sourceType, 
                                MessageType targetType, MessageMetadata metadata);

    /**
     * Auto-detects source format and translates to target format.
     */
    TranslationResult translate(String rawMessage, MessageType targetType, MessageMetadata metadata);

    /**
     * Result of a translation operation.
     */
    record TranslationResult(
        String output,
        MessageType sourceType,
        MessageType targetType,
        MessageMetadata metadata,
        boolean success,
        String warnings,
        long processingTimeMs
    ) {}
}
