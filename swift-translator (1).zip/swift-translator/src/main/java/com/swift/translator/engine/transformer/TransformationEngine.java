package com.swift.translator.engine.transformer;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Engine for applying transformations to field values.
 * 
 * <p>Parses transformation expressions and executes them using the FunctionRegistry.</p>
 */
@Slf4j
@Component
public class TransformationEngine {

    private static final Pattern FUNCTION_PATTERN = Pattern.compile(
        "([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]*)\)"
    );
    private static final Pattern ARGUMENT_PATTERN = Pattern.compile(
        "'([^']*)'|"([^"]*)"|([^,\s]+)"
    );

    private final FunctionRegistry functionRegistry;

    public TransformationEngine(FunctionRegistry functionRegistry) {
        this.functionRegistry = functionRegistry;
    }

    /**
     * Applies a transformation expression to a value.
     * 
     * @param value the input value
     * @param expression the transformation expression (e.g., "uppercase(value)")
     * @return the transformed value
     */
    public Object transform(Object value, String expression) {
        if (expression == null || expression.trim().isEmpty()) {
            return value;
        }

        log.debug("Applying transformation: {} to value: {}", expression, value);

        try {
            return evaluateExpression(value, expression);
        } catch (Exception e) {
            log.warn("Transformation failed: {}. Returning original value.", e.getMessage());
            return value;
        }
    }

    /**
     * Applies a chain of transformations.
     */
    public Object transformChain(Object value, List<String> expressions) {
        Object result = value;
        for (String expression : expressions) {
            result = transform(result, expression);
        }
        return result;
    }

    private Object evaluateExpression(Object value, String expression) {
        // Replace "value" placeholder with actual value
        String processedExpr = expression.replace("value", "'" + escapeString(toString(value)) + "'");

        Matcher matcher = FUNCTION_PATTERN.matcher(processedExpr);
        if (matcher.matches()) {
            String functionName = matcher.group(1);
            String argsStr = matcher.group(2);
            List<Object> args = parseArguments(argsStr, value);
            return functionRegistry.execute(functionName, args);
        }

        // If no function pattern, return as-is or try simple operations
        return processedExpr;
    }

    private List<Object> parseArguments(String argsStr, Object contextValue) {
        List<Object> args = new ArrayList<>();
        if (argsStr == null || argsStr.trim().isEmpty()) {
            return args;
        }

        // Simple comma-separated parsing (handles quoted strings)
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;
        char quoteChar = 0;

        for (char c : argsStr.toCharArray()) {
            if (!inQuotes && (c == ''' || c == '"')) {
                inQuotes = true;
                quoteChar = c;
            } else if (inQuotes && c == quoteChar) {
                inQuotes = false;
                quoteChar = 0;
            } else if (!inQuotes && c == ',') {
                args.add(parseArgument(current.toString().trim(), contextValue));
                current = new StringBuilder();
                continue;
            }
            current.append(c);
        }

        if (!current.isEmpty()) {
            args.add(parseArgument(current.toString().trim(), contextValue));
        }

        return args;
    }

    private Object parseArgument(String arg, Object contextValue) {
        arg = arg.trim();

        // String literal
        if ((arg.startsWith("'") && arg.endsWith("'")) || 
            (arg.startsWith(""") && arg.endsWith("""))) {
            return arg.substring(1, arg.length() - 1);
        }

        // Numeric
        try {
            if (arg.contains(".")) {
                return Double.parseDouble(arg);
            }
            return Long.parseLong(arg);
        } catch (NumberFormatException e) {
            // Not a number
        }

        // Boolean
        if ("true".equalsIgnoreCase(arg) || "false".equalsIgnoreCase(arg)) {
            return Boolean.parseBoolean(arg);
        }

        // Context reference (field path like "block4.tag20")
        if (arg.contains(".")) {
            return arg; // Return as string reference, to be resolved by caller
        }

        return arg;
    }

    private String toString(Object obj) {
        return obj == null ? "" : obj.toString();
    }

    private String escapeString(String str) {
        return str.replace("'", "\'").replace(""", "\"");
    }
}
