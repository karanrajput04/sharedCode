package com.swift.translator.engine.parser;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.message.MessageFormat;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ParsingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Parser for JSON format messages.
 * 
 * <p>Converts JSON structure to canonical model using path-based extraction.</p>
 */
@Slf4j
@Component
public class JsonMessageParser implements MessageParser {

    private final ObjectMapper objectMapper;

    public JsonMessageParser(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public boolean supports(MessageType messageType) {
        return messageType != null && messageType.getFormat() == MessageFormat.JSON;
    }

    @Override
    public CanonicalMessage parse(String content, MessageType messageType, MessageMetadata metadata) {
        log.debug("Parsing JSON message, correlationId: {}", metadata.getCorrelationId());

        try {
            JsonNode root = objectMapper.readTree(content);

            CanonicalMessage.CanonicalMessageBuilder builder = CanonicalMessage.builder();
            builder.rawPayload(content.substring(0, Math.min(1000, content.length())));

            return builder.build();

        } catch (Exception e) {
            throw new ParsingException("Failed to parse JSON message: " + e.getMessage(), e,
                "JSON_PARSE_ERROR", metadata);
        }
    }

    @Override
    public String getFormat() {
        return "JSON";
    }
}
