package com.swift.translator.domain.exception;

import com.swift.translator.domain.model.message.MessageMetadata;

/**
 * Exception thrown when field mapping fails.
 */
public class MappingException extends TranslationException {

    private final String sourceField;
    private final String targetField;

    public MappingException(String message, String sourceField, String targetField,
                            String errorCode, MessageMetadata metadata) {
        super(message, errorCode, metadata);
        this.sourceField = sourceField;
        this.targetField = targetField;
    }

    public MappingException(String message, Throwable cause, String sourceField, String targetField,
                            String errorCode, MessageMetadata metadata) {
        super(message, cause, errorCode, metadata);
        this.sourceField = sourceField;
        this.targetField = targetField;
    }
}
