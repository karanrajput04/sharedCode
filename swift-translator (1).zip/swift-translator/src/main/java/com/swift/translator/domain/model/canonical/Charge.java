package com.swift.translator.domain.model.canonical;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Represents a charge or fee in a transaction.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class Charge {

    private final BigDecimal amount;
    private final String currency;
    private final String chargeBearer;
    private final String chargeType;
    private final String chargeTypeCode;
}
