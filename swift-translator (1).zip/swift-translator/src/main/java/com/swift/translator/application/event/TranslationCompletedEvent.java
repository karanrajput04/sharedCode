package com.swift.translator.application.event;

import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import lombok.Builder;
import lombok.Getter;

import java.time.Instant;

/**
 * Event published when a translation completes successfully.
 */
@Getter
@Builder
public class TranslationCompletedEvent {

    private final String correlationId;
    private final MessageType sourceType;
    private final MessageType targetType;
    private final long processingTimeMs;
    private final Instant completedAt;
    private final String outputHash;
    private final int outputSize;

    public static TranslationCompletedEvent from(TranslateMessageUseCase.TranslationResult result) {
        MessageMetadata metadata = result.metadata();
        return TranslationCompletedEvent.builder()
            .correlationId(metadata.getCorrelationId())
            .sourceType(result.sourceType())
            .targetType(result.targetType())
            .processingTimeMs(result.processingTimeMs())
            .completedAt(Instant.now())
            .outputHash(hashOutput(result.output()))
            .outputSize(result.output() != null ? result.output().length() : 0)
            .build();
    }

    private static String hashOutput(String output) {
        if (output == null) return "";
        return Integer.toHexString(output.hashCode());
    }
}
