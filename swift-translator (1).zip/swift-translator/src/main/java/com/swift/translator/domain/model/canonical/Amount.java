package com.swift.translator.domain.model.canonical;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.math.BigDecimal;

/**
 * Represents a monetary amount with currency.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class Amount {

    private final AmountType type;
    private final BigDecimal value;
    private final String currency;
    private final Integer decimalPlaces;
    private final BigDecimal exchangeRate;
    private final String exchangeRateType;
    private final String exchangeRateContractId;

    /**
     * Validates that the amount has a positive value and valid currency.
     */
    public boolean isValid() {
        return value != null 
            && value.compareTo(BigDecimal.ZERO) > 0 
            && currency != null 
            && currency.matches("^[A-Z]{3}$");
    }

    /**
     * Returns the amount formatted as "value currency" (e.g., "1000.00 EUR").
     */
    public String toFormattedString() {
        return String.format("%s %s", value.toPlainString(), currency);
    }
}
