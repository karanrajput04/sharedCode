package com.swift.translator.application.port.inbound;

import java.time.Instant;
import java.util.Optional;

/**
 * Primary port for querying translation status.
 */
public interface GetTranslationStatusUseCase {

    /**
     * Gets the status of a translation by correlation ID.
     */
    Optional<TranslationStatus> getStatus(String correlationId);

    /**
     * Translation status record.
     */
    record TranslationStatus(
        String correlationId,
        String status, // PENDING, PROCESSING, COMPLETED, FAILED
        String sourceType,
        String targetType,
        Instant createdAt,
        Instant completedAt,
        String errorMessage,
        String outputPreview
    ) {}
}
