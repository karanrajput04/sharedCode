package com.swift.translator.domain.model.config;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Singular;
import lombok.ToString;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Configuration for mapping between message types.
 * 
 * <p>Loaded from YAML/JSON/XML configuration files.</p>
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class MappingConfiguration {

    private final String id;
    private final String version;
    private final String sourceFormat;
    private final String sourceType;
    private final String targetFormat;
    private final String targetType;
    private final String description;

    @Singular
    private final List<FieldMapping> fieldMappings;

    @Singular
    private final List<TransformationConfig> transformations;

    public List<FieldMapping> getFieldMappings() {
        return fieldMappings == null ? Collections.emptyList() : Collections.unmodifiableList(fieldMappings);
    }

    public List<TransformationConfig> getTransformations() {
        return transformations == null ? Collections.emptyList() : Collections.unmodifiableList(transformations);
    }

    /**
     * Individual field mapping definition.
     */
    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class FieldMapping {
        private final String target;
        private final String source;
        private final boolean required;
        private final String defaultValue;
        private final String fallbackValue;
        private final String transformation;
        private final ConditionConfig condition;
        private final ExtractionConfig extraction;
        private final CompositeConfig composite;
        private final LoopConfig loop;
        private final List<FieldMapping> itemMappings;
    }

    /**
     * Condition configuration for conditional mappings.
     */
    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class ConditionConfig {
        private final String ifCondition;
        private final String thenValue;
        private final String elseIfCondition;
        private final String elseIfValue;
        private final String elseValue;
    }

    /**
     * Extraction configuration (XPath, JSONPath, Regex).
     */
    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class ExtractionConfig {
        private final String type; // XPATH, JSONPATH, REGEX
        private final String expression;
        private final int group;
    }

    /**
     * Composite field configuration.
     */
    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class CompositeConfig {
        @Singular
        private final List<CompositePart> parts;
    }

    /**
     * Part of a composite field.
     */
    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class CompositePart {
        private final String source;
        private final String constant;
    }

    /**
     * Loop configuration for collection mappings.
     */
    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class LoopConfig {
        private final String expression;
        private final String itemName;
    }

    /**
     * Named transformation configuration.
     */
    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class TransformationConfig {
        private final String name;
        private final String function;
        private final Map<String, String> params;
    }
}
