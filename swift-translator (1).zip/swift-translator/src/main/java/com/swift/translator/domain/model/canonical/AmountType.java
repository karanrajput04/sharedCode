package com.swift.translator.domain.model.canonical;

/**
 * Types of amounts in financial messages.
 */
public enum AmountType {
    INSTRUCTED,
    INTERBANK_SETTLEMENT,
    EQUIVALENT,
    COUNTER_VALUE,
    CHARGES,
    TAX,
    INTEREST,
    ORIGINAL,
    RECALLED,
    ACCEPTED,
    AUTHORISED
}
