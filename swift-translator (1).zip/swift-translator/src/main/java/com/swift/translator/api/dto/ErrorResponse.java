package com.swift.translator.api.dto;

import com.swift.translator.domain.exception.ValidationException;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * DTO for error responses.
 */
@Data
@Builder
public class ErrorResponse {

    /**
     * Error code.
     */
    private String errorCode;

    /**
     * Human-readable error message.
     */
    private String message;

    /**
     * Correlation ID for tracing.
     */
    private String correlationId;

    /**
     * Processing stage where error occurred.
     */
    private String stage;

    /**
     * Validation errors if applicable.
     */
    private List<ValidationException.ValidationError> validationErrors;

    /**
     * Response timestamp.
     */
    private String timestamp;

    /**
     * Whether the operation is retryable.
     */
    private boolean retryable;
}
