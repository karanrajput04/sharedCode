package com.swift.translator.application.event;

import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import lombok.Builder;
import lombok.Getter;

import java.time.Instant;

/**
 * Event published when a translation fails.
 */
@Getter
@Builder
public class TranslationFailedEvent {

    private final String correlationId;
    private final MessageType sourceType;
    private final MessageType targetType;
    private final String errorCode;
    private final String errorMessage;
    private final String stage;
    private final Instant failedAt;
    private final boolean retryable;

    public static TranslationFailedEvent from(String correlationId, Throwable error, 
                                               MessageType sourceType, MessageType targetType,
                                               String stage, boolean retryable) {
        return TranslationFailedEvent.builder()
            .correlationId(correlationId)
            .sourceType(sourceType)
            .targetType(targetType)
            .errorCode(error instanceof com.swift.translator.domain.exception.TranslationException 
                ? ((com.swift.translator.domain.exception.TranslationException) error).getErrorCode() 
                : "UNKNOWN")
            .errorMessage(error.getMessage())
            .stage(stage)
            .failedAt(Instant.now())
            .retryable(retryable)
            .build();
    }
}
