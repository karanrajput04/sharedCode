package com.swift.translator.engine.parser;

import com.swift.translator.domain.model.canonical.*;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ParsingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import java.io.StringReader;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Parser for ISO 20022 MX (XML) messages.
 * 
 * <p>Supports pacs.008, pacs.009, pain.001, pain.002, camt.052, camt.053, camt.054
 * and other ISO 20022 message types.</p>
 */
@Slf4j
@Component
public class MxMessageParser implements MessageParser {

    private static final DateTimeFormatter ISO_DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final DateTimeFormatter ISO_DATETIME_FORMAT = DateTimeFormatter.ISO_DATE_TIME;

    private final XPathFactory xPathFactory;
    private final DocumentBuilderFactory docBuilderFactory;

    public MxMessageParser() {
        this.xPathFactory = XPathFactory.newInstance();
        this.docBuilderFactory = DocumentBuilderFactory.newInstance();
        this.docBuilderFactory.setNamespaceAware(true);
        this.docBuilderFactory.setIgnoringComments(true);
        try {
            this.docBuilderFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            this.docBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            this.docBuilderFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        } catch (Exception e) {
            log.warn("Could not set all XML security features", e);
        }
    }

    @Override
    public boolean supports(MessageType messageType) {
        return messageType != null && messageType.isMx();
    }

    @Override
    public CanonicalMessage parse(String content, MessageType messageType, MessageMetadata metadata) {
        log.debug("Parsing MX message type: {}, correlationId: {}", messageType.getTypeCode(), metadata.getCorrelationId());

        try {
            DocumentBuilder builder = docBuilderFactory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(content)));
            document.getDocumentElement().normalize();

            XPath xpath = xPathFactory.newXPath();

            return buildCanonicalMessage(document, xpath, messageType, metadata);

        } catch (ParsingException e) {
            throw e;
        } catch (SAXException e) {
            throw new ParsingException("Invalid XML structure: " + e.getMessage(), e,
                "MX_PARSE_XML", metadata);
        } catch (Exception e) {
            throw new ParsingException("Failed to parse MX message: " + e.getMessage(), e,
                "MX_PARSE_ERROR", metadata);
        }
    }

    private CanonicalMessage buildCanonicalMessage(Document doc, XPath xpath, 
                                                   MessageType messageType, MessageMetadata metadata) {
        CanonicalMessage.CanonicalMessageBuilder builder = CanonicalMessage.builder();

        builder.header(parseHeader(doc, xpath, messageType));
        builder.transaction(parseTransaction(doc, xpath, metadata));
        builder.parties(parseParties(doc, xpath, metadata));
        builder.amounts(parseAmounts(doc, xpath, metadata));
        builder.references(parseReferences(doc, xpath, metadata));
        builder.narratives(parseNarratives(doc, xpath, metadata));
        builder.rawPayload(contentLimit(doc));

        return builder.build();
    }

    private MessageHeader parseHeader(Document doc, XPath xpath, MessageType messageType) {
        MessageHeader.MessageHeaderBuilder header = MessageHeader.builder()
            .messageType(messageType);

        evaluateXPath(xpath, doc, "//GrpHdr/MsgId").ifPresent(header::messageId);
        evaluateXPath(xpath, doc, "//GrpHdr/CreDtTm").ifPresent(v -> {
            try {
                header.creationDateTime(LocalDateTime.parse(v, ISO_DATETIME_FORMAT));
            } catch (Exception e) {
                log.warn("Failed to parse creation date time: {}", v);
            }
        });
        evaluateXPath(xpath, doc, "//GrpHdr/InstgAgt/FinInstnId/BICFI").ifPresent(header::senderBic);
        evaluateXPath(xpath, doc, "//GrpHdr/InstdAgt/FinInstnId/BICFI").ifPresent(header::receiverBic);

        return header.build();
    }

    private Transaction parseTransaction(Document doc, XPath xpath, MessageMetadata metadata) {
        Transaction.TransactionBuilder transaction = Transaction.builder();

        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtId/InstrId").ifPresent(transaction::transactionReference);
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtId/EndToEndId").ifPresent(transaction::relatedReference);
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/IntrBkSttlmDt").ifPresent(v -> {
            try {
                transaction.interbankSettlementDate(v);
                transaction.valueDate(LocalDate.parse(v, ISO_DATE_FORMAT));
            } catch (Exception e) {
                log.warn("Failed to parse settlement date: {}", v);
            }
        });
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/ChrgBr").ifPresent(transaction::chargeBearer);
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtTpInf/SvcLvl/Cd").ifPresent(transaction::serviceLevel);
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtTpInf/LclInstrm/Cd").ifPresent(transaction::localInstrument);
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtTpInf/CtgyPurp/Cd").ifPresent(transaction::categoryPurpose);
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/ClrChanl").ifPresent(transaction::clearingChannel);

        return transaction.build();
    }

    private List<Party> parseParties(Document doc, XPath xpath, MessageMetadata metadata) {
        List<Party> parties = new ArrayList<>();

        parseParty(doc, xpath, "//Dbtr", PartyRole.DEBTOR).ifPresent(parties::add);
        parseParty(doc, xpath, "//DbtrAgt", PartyRole.DEBTOR_AGENT).ifPresent(parties::add);
        parseParty(doc, xpath, "//Cdtr", PartyRole.CREDITOR).ifPresent(parties::add);
        parseParty(doc, xpath, "//CdtrAgt", PartyRole.CREDITOR_AGENT).ifPresent(parties::add);
        parseParty(doc, xpath, "//IntrmyAgt1", PartyRole.INTERMEDIARY_AGENT_1).ifPresent(parties::add);
        parseParty(doc, xpath, "//IntrmyAgt2", PartyRole.INTERMEDIARY_AGENT_2).ifPresent(parties::add);
        parseParty(doc, xpath, "//IntrmyAgt3", PartyRole.INTERMEDIARY_AGENT_3).ifPresent(parties::add);
        parseParty(doc, xpath, "//UltmtDbtr", PartyRole.ULTIMATE_DEBTOR).ifPresent(parties::add);
        parseParty(doc, xpath, "//UltmtCdtr", PartyRole.ULTIMATE_CREDITOR).ifPresent(parties::add);

        return parties;
    }

    private Optional<Party> parseParty(Document doc, XPath xpath, String baseXPath, PartyRole role) {
        Optional<String> name = evaluateXPath(xpath, doc, baseXPath + "/Nm");
        Optional<String> bicfi = evaluateXPath(xpath, doc, baseXPath + "/FinInstnId/BICFI");
        Optional<String> account = evaluateXPath(xpath, doc, baseXPath + "/Acct/Id/Othr/Id");

        if (name.isEmpty() && bicfi.isEmpty() && account.isEmpty()) {
            return Optional.empty();
        }

        Party.PartyBuilder party = Party.builder().role(role);
        name.ifPresent(party::name);
        bicfi.ifPresent(party::bicfi);
        account.ifPresent(party::accountNumber);

        evaluateXPath(xpath, doc, baseXPath + "/PstlAdr/AdrLine[1]").ifPresent(party::address);
        evaluateXPath(xpath, doc, baseXPath + "/PstlAdr/Ctry").ifPresent(party::country);
        evaluateXPath(xpath, doc, baseXPath + "/PstlAdr/TwnNm").ifPresent(party::city);
        evaluateXPath(xpath, doc, baseXPath + "/Id/OrgId/Othr/Id").ifPresent(party::organizationId);
        evaluateXPath(xpath, doc, baseXPath + "/Id/PrvtId/Othr/Id").ifPresent(party::privateId);
        evaluateXPath(xpath, doc, baseXPath + "/CtctDtls/Nm").ifPresent(party::contactName);
        evaluateXPath(xpath, doc, baseXPath + "/CtctDtls/PhneNb").ifPresent(party::contactPhone);
        evaluateXPath(xpath, doc, baseXPath + "/CtctDtls/EmailAdr").ifPresent(party::contactEmail);

        return Optional.of(party.build());
    }

    private List<Amount> parseAmounts(Document doc, XPath xpath, MessageMetadata metadata) {
        List<Amount> amounts = new ArrayList<>();

        parseAmount(doc, xpath, "//CdtTrfTxInf/IntrBkSttlmAmt", AmountType.INTERBANK_SETTLEMENT)
            .ifPresent(amounts::add);
        parseAmount(doc, xpath, "//CdtTrfTxInf/InstdAmt", AmountType.INSTRUCTED)
            .ifPresent(amounts::add);
        parseAmount(doc, xpath, "//CdtTrfTxInf/EqvtAmt/Amt", AmountType.EQUIVALENT)
            .ifPresent(amounts::add);
        parseAmount(doc, xpath, "//CdtTrfTxInf/ChrgsInf/Amt", AmountType.CHARGES)
            .ifPresent(amounts::add);

        return amounts;
    }

    private Optional<Amount> parseAmount(Document doc, XPath xpath, String xpathExpr, AmountType type) {
        try {
            Optional<String> valueStr = evaluateXPath(xpath, doc, xpathExpr);
            if (valueStr.isEmpty()) return Optional.empty();

            NodeList nodes = (NodeList) xpath.evaluate(xpathExpr, doc, XPathConstants.NODESET);
            if (nodes.getLength() == 0) return Optional.empty();

            Element element = (Element) nodes.item(0);
            String currency = element.getAttribute("Ccy");
            if (currency == null || currency.isEmpty()) {
                currency = element.getParentNode() != null ? 
                    ((Element) element.getParentNode()).getAttribute("Ccy") : "";
            }

            BigDecimal value = new BigDecimal(valueStr.get());
            return Optional.of(Amount.builder()
                .type(type)
                .value(value)
                .currency(currency)
                .build());

        } catch (Exception e) {
            log.warn("Failed to parse amount at {}: {}", xpathExpr, e.getMessage());
            return Optional.empty();
        }
    }

    private List<Reference> parseReferences(Document doc, XPath xpath, MessageMetadata metadata) {
        List<Reference> references = new ArrayList<>();

        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtId/InstrId").ifPresent(v -> 
            references.add(Reference.builder().type("INSTRUCTION_ID").value(v).build()));
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtId/EndToEndId").ifPresent(v -> 
            references.add(Reference.builder().type("END_TO_END_ID").value(v).build()));
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtId/TxId").ifPresent(v -> 
            references.add(Reference.builder().type("TRANSACTION_ID").value(v).build()));
        evaluateXPath(xpath, doc, "//CdtTrfTxInf/PmtId/UETR").ifPresent(v -> 
            references.add(Reference.builder().type("UETR").value(v).build()));

        return references;
    }

    private List<Narrative> parseNarratives(Document doc, XPath xpath, MessageMetadata metadata) {
        List<Narrative> narratives = new ArrayList<>();

        try {
            NodeList rmtNodes = (NodeList) xpath.evaluate("//RmtInf//Ustrd", doc, XPathConstants.NODESET);
            if (rmtNodes.getLength() > 0) {
                List<String> lines = new ArrayList<>();
                for (int i = 0; i < rmtNodes.getLength(); i++) {
                    lines.add(rmtNodes.item(i).getTextContent());
                }
                narratives.add(Narrative.builder()
                    .code("REMITTANCE_INFO")
                    .lines(lines)
                    .fullText(String.join("\n", lines))
                    .build());
            }
        } catch (Exception e) {
            log.trace("No remittance information found");
        }

        return narratives;
    }

    private Optional<String> evaluateXPath(XPath xpath, Document doc, String expression) {
        try {
            String result = (String) xpath.evaluate(expression, doc, XPathConstants.STRING);
            if (result != null && !result.trim().isEmpty()) {
                return Optional.of(result.trim());
            }
        } catch (XPathExpressionException e) {
            log.trace("XPath evaluation failed for: {}", expression);
        }
        return Optional.empty();
    }

    private String contentLimit(Document doc) {
        try {
            return doc.getDocumentElement().getTextContent().substring(0, 
                Math.min(1000, doc.getDocumentElement().getTextContent().length()));
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public String getFormat() {
        return "MX";
    }
}
