package com.swift.translator.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Date utility methods.
 */
public final class DateUtils {

    private DateUtils() {
        // Utility class
    }

    public static final DateTimeFormatter SWIFT_DATE_FORMAT = DateTimeFormatter.ofPattern("yyMMdd");
    public static final DateTimeFormatter ISO_DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;
    public static final DateTimeFormatter ISO_DATETIME_FORMAT = DateTimeFormatter.ISO_DATE_TIME;

    public static LocalDate parseSwiftDate(String dateStr) {
        try {
            return LocalDate.parse(dateStr, SWIFT_DATE_FORMAT);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static String formatSwiftDate(LocalDate date) {
        return date.format(SWIFT_DATE_FORMAT);
    }

    public static LocalDate parseIsoDate(String dateStr) {
        try {
            return LocalDate.parse(dateStr, ISO_DATE_FORMAT);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static String formatIsoDate(LocalDate date) {
        return date.format(ISO_DATE_FORMAT);
    }
}
