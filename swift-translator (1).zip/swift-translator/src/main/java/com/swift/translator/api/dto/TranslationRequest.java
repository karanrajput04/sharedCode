package com.swift.translator.api.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

/**
 * DTO for translation requests.
 */
@Data
@Builder
public class TranslationRequest {

    /**
     * The raw message content to translate.
     */
    @NotBlank(message = "Message content is required")
    private String message;

    /**
     * Source message type (e.g., "MT103", "pacs.008.001.08").
     * If not provided, auto-detection will be used.
     */
    private String sourceType;

    /**
     * Target message type (e.g., "pacs.008.001.08", "MT103").
     */
    @NotBlank(message = "Target type is required")
    private String targetType;

    /**
     * Optional business message identifier.
     */
    private String messageId;

    /**
     * Optional routing information.
     */
    private String routingInfo;

    /**
     * Optional transformation options.
     */
    private TranslationOptions options;

    /**
     * Translation options.
     */
    @Data
    @Builder
    public static class TranslationOptions {
        private boolean validateInput;
        private boolean validateOutput;
        private boolean applyBusinessRules;
        private boolean includeRawPayload;
        private String characterEncoding;
    }
}
