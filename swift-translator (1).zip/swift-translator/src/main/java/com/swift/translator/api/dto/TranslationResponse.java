package com.swift.translator.api.dto;

import lombok.Builder;
import lombok.Data;

/**
 * DTO for translation responses.
 */
@Data
@Builder
public class TranslationResponse {

    /**
     * Correlation ID for tracing.
     */
    private String correlationId;

    /**
     * The translated message content.
     */
    private String output;

    /**
     * Detected or specified source message type.
     */
    private String sourceType;

    /**
     * Target message type.
     */
    private String targetType;

    /**
     * Processing time in milliseconds.
     */
    private long processingTimeMs;

    /**
     * Whether translation was successful.
     */
    private boolean success;

    /**
     * Any warnings generated during translation.
     */
    private String warnings;

    /**
     * Response timestamp.
     */
    private String timestamp;

    /**
     * Output message hash for integrity verification.
     */
    private String outputHash;
}
