package com.swift.translator.engine.parser;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;

/**
 * Strategy interface for parsing raw messages into canonical form.
 * 
 * <p>Implementations handle specific formats (MT, MX, JSON, CSV, Text).</p>
 */
public interface MessageParser {

    /**
     * Checks if this parser supports the given message type.
     */
    boolean supports(MessageType messageType);

    /**
     * Parses raw message content into canonical form.
     * 
     * @param content raw message content
     * @param messageType the detected message type
     * @param metadata message metadata for error context
     * @return parsed canonical message
     * @throws com.swift.translator.domain.exception.ParsingException if parsing fails
     */
    CanonicalMessage parse(String content, MessageType messageType, MessageMetadata metadata);

    /**
     * Returns the format this parser handles.
     */
    String getFormat();
}
