package com.swift.translator.infrastructure.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * Performance timing utility for measuring operation durations.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PerformanceTimer {

    private final MeterRegistry meterRegistry;

    /**
     * Times a supplier operation and records metrics.
     */
    public <T> T time(String operation, String... tags, Supplier<T> supplier) {
        long startTime = System.currentTimeMillis();
        try {
            return supplier.get();
        } finally {
            long duration = System.currentTimeMillis() - startTime;
            Timer.builder("operation.duration")
                .tag("operation", operation)
                .tags(tags)
                .register(meterRegistry)
                .record(duration, TimeUnit.MILLISECONDS);

            if (duration > 100) {
                log.warn("Slow operation detected: {} took {}ms", operation, duration);
            }
        }
    }

    /**
     * Times a runnable operation.
     */
    public void time(String operation, String[] tags, Runnable runnable) {
        time(operation, tags, () -> {
            runnable.run();
            return null;
        });
    }
}
