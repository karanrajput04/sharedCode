package com.swift.translator.engine.rule;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.canonical.Party;
import com.swift.translator.domain.model.canonical.PartyRole;
import com.swift.translator.domain.model.canonical.Amount;
import com.swift.translator.domain.model.config.RuleConfiguration;
import com.swift.translator.domain.model.config.RuleConfiguration.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Rule engine for evaluating business rules against canonical messages.
 * 
 * <p>Supports conditions, nested conditions, boolean logic (AND/OR/NOT),
 * expression language (SpEL), priority, rule chaining, and custom rules.</p>
 */
@Slf4j
@Component
public class RuleEngine {

    private final SpelExpressionParser expressionParser;

    public RuleEngine() {
        this.expressionParser = new SpelExpressionParser();
    }

    /**
     * Evaluates all rules against the message and returns results.
     * 
     * @param message the canonical message to evaluate
     * @param config the rule configuration
     * @return rule evaluation result
     */
    public RuleResult evaluate(CanonicalMessage message, RuleConfiguration config) {
        if (config == null || config.getRules().isEmpty()) {
            log.debug("No rules to evaluate");
            return new RuleResult(true, Collections.emptyList(), Collections.emptyList());
        }

        List<RuleViolation> violations = new ArrayList<>();
        List<String> flags = new ArrayList<>();

        // Sort by priority (lower number = higher priority)
        List<Rule> sortedRules = config.getRules().stream()
            .sorted(Comparator.comparingInt(Rule::getPriority))
            .toList();

        log.debug("Evaluating {} rules", sortedRules.size());

        for (Rule rule : sortedRules) {
            try {
                boolean matched = evaluateCondition(message, rule.getCondition());

                if (matched) {
                    log.debug("Rule matched: {} - Action: {}", rule.getName(), rule.getAction());

                    switch (rule.getAction().toUpperCase()) {
                        case "BLOCK", "REJECT" -> {
                            violations.add(new RuleViolation(rule.getId(), rule.getMessage(), "ERROR"));
                            log.warn("Rule {} BLOCKED message: {}", rule.getId(), rule.getMessage());
                        }
                        case "FLAG" -> {
                            flags.add(rule.getMessage());
                            log.info("Rule {} FLAGGED message: {}", rule.getId(), rule.getMessage());
                        }
                        case "WARN", "WARNING" -> {
                            violations.add(new RuleViolation(rule.getId(), rule.getMessage(), "WARNING"));
                            log.warn("Rule {} warning: {}", rule.getId(), rule.getMessage());
                        }
                        case "ALLOW" -> {
                            log.debug("Rule {} ALLOWED", rule.getId());
                        }
                        default -> log.warn("Unknown rule action: {}", rule.getAction());
                    }

                    if (rule.isStopOnMatch()) {
                        log.debug("Stopping rule evaluation due to stopOnMatch for rule {}", rule.getId());
                        break;
                    }
                }
            } catch (Exception e) {
                log.error("Error evaluating rule {}: {}", rule.getId(), e.getMessage(), e);
                violations.add(new RuleViolation(rule.getId(), 
                    "Rule evaluation error: " + e.getMessage(), "ERROR"));
            }
        }

        boolean allowed = violations.stream().noneMatch(v -> "ERROR".equals(v.severity()));

        log.debug("Rule evaluation complete. Allowed: {}, Violations: {}, Flags: {}", 
            allowed, violations.size(), flags.size());

        return new RuleResult(allowed, violations, flags);
    }

    /**
     * Evaluates a condition against the message.
     */
    private boolean evaluateCondition(CanonicalMessage message, Condition condition) {
        if (condition == null) return true;

        String type = condition.getType();
        if (type == null) type = "FIELD";

        return switch (type.toUpperCase()) {
            case "AND" -> {
                if (condition.getConditions() == null || condition.getConditions().isEmpty()) {
                    yield true;
                }
                yield condition.getConditions().stream()
                    .allMatch(c -> evaluateCondition(message, c));
            }
            case "OR" -> {
                if (condition.getConditions() == null || condition.getConditions().isEmpty()) {
                    yield false;
                }
                yield condition.getConditions().stream()
                    .anyMatch(c -> evaluateCondition(message, c));
            }
            case "NOT" -> {
                if (condition.getConditions() == null || condition.getConditions().isEmpty()) {
                    yield true;
                }
                yield !evaluateCondition(message, condition.getConditions().get(0));
            }
            case "FIELD" -> evaluateFieldCondition(message, condition);
            default -> {
                log.warn("Unknown condition type: {}", type);
                yield false;
            }
        };
    }

    /**
     * Evaluates a field-level condition using SpEL or simple comparison.
     */
    private boolean evaluateFieldCondition(CanonicalMessage message, Condition condition) {
        String field = condition.getField();
        String operator = condition.getOperator();
        Object value = condition.getValue();

        if (field == null || operator == null) {
            log.warn("Field condition missing field or operator");
            return false;
        }

        Object fieldValue = resolveFieldValue(message, field);
        String fieldStr = fieldValue != null ? fieldValue.toString() : "";
        String valueStr = value != null ? value.toString() : "";

        return switch (operator.toUpperCase()) {
            case "EQUALS", "==", "EQ" -> fieldStr.equals(valueStr);
            case "NOT_EQUALS", "!=", "NEQ" -> !fieldStr.equals(valueStr);
            case "GREATER_THAN", ">", "GT" -> compareValues(fieldValue, value) > 0;
            case "LESS_THAN", "<", "LT" -> compareValues(fieldValue, value) < 0;
            case "GREATER_THAN_OR_EQUAL", ">=", "GTE" -> compareValues(fieldValue, value) >= 0;
            case "LESS_THAN_OR_EQUAL", "<=", "LTE" -> compareValues(fieldValue, value) <= 0;
            case "CONTAINS" -> fieldStr.contains(valueStr);
            case "STARTS_WITH" -> fieldStr.startsWith(valueStr);
            case "ENDS_WITH" -> fieldStr.endsWith(valueStr);
            case "MATCHES" -> {
                try {
                    yield Pattern.compile(valueStr).matcher(fieldStr).matches();
                } catch (PatternSyntaxException e) {
                    log.warn("Invalid regex pattern: {}", valueStr);
                    yield false;
                }
            }
            case "IN" -> {
                if (value instanceof List<?> list) {
                    yield list.stream().anyMatch(v -> fieldStr.equals(v.toString()));
                }
                yield fieldStr.equals(valueStr);
            }
            case "NOT_IN" -> {
                if (value instanceof List<?> list) {
                    yield list.stream().noneMatch(v -> fieldStr.equals(v.toString()));
                }
                yield !fieldStr.equals(valueStr);
            }
            case "IS_EMPTY" -> fieldStr.isEmpty();
            case "IS_NOT_EMPTY" -> !fieldStr.isEmpty();
            case "IS_NULL" -> fieldValue == null;
            case "IS_NOT_NULL" -> fieldValue != null;
            default -> {
                log.warn("Unknown operator: {}", operator);
                yield false;
            }
        };
    }

    /**
     * Resolves a field value from the canonical message using path notation.
     */
    private Object resolveFieldValue(CanonicalMessage message, String fieldPath) {
        if (fieldPath == null || fieldPath.isEmpty()) return null;

        // Handle special prefixes
        if (fieldPath.startsWith("party.")) {
            String roleStr = fieldPath.substring(6);
            String fieldName = "name";

            if (roleStr.contains(".")) {
                int dotIndex = roleStr.indexOf('.');
                fieldName = roleStr.substring(dotIndex + 1);
                roleStr = roleStr.substring(0, dotIndex);
            }

            try {
                PartyRole role = PartyRole.valueOf(roleStr.toUpperCase().replace("-", "_"));
                Optional<Party> party = message.getPartyByRole(role);
                if (party.isPresent()) {
                    return getPartyField(party.get(), fieldName);
                }
            } catch (IllegalArgumentException e) {
                log.trace("Unknown party role: {}", roleStr);
            }
            return null;
        }

        if (fieldPath.startsWith("amount.")) {
            String amountTypeStr = fieldPath.substring(7);
            String fieldName = "value";

            if (amountTypeStr.contains(".")) {
                int dotIndex = amountTypeStr.indexOf('.');
                fieldName = amountTypeStr.substring(dotIndex + 1);
                amountTypeStr = amountTypeStr.substring(0, dotIndex);
            }

            try {
                // Try to find amount by type
                for (Amount amount : message.getAmounts()) {
                    if (amount.getType().name().equalsIgnoreCase(amountTypeStr) ||
                        amount.getType().name().equalsIgnoreCase(amountTypeStr.replace("-", "_"))) {
                        return getAmountField(amount, fieldName);
                    }
                }
            } catch (Exception e) {
                log.trace("Error resolving amount field: {}", fieldPath);
            }
            return null;
        }

        if (fieldPath.startsWith("header.")) {
            if (message.getHeader() == null) return null;
            String fieldName = fieldPath.substring(7);
            return getHeaderField(message.getHeader(), fieldName);
        }

        if (fieldPath.startsWith("transaction.")) {
            if (message.getTransaction() == null) return null;
            String fieldName = fieldPath.substring(12);
            return getTransactionField(message.getTransaction(), fieldName);
        }

        // Try SpEL evaluation for complex expressions
        try {
            StandardEvaluationContext context = new StandardEvaluationContext(message);
            context.setVariable("message", message);
            context.setVariable("header", message.getHeader());
            context.setVariable("transaction", message.getTransaction());

            return expressionParser.parseExpression(fieldPath).getValue(context);
        } catch (Exception e) {
            log.trace("SpEL evaluation failed for: {}", fieldPath);
            return null;
        }
    }

    private Object getPartyField(Party party, String fieldName) {
        return switch (fieldName.toLowerCase()) {
            case "name" -> party.getName();
            case "address" -> party.getAddress();
            case "city" -> party.getCity();
            case "country" -> party.getCountry();
            case "postalcode", "postal_code" -> party.getPostalCode();
            case "account", "accountnumber", "account_number" -> party.getAccountNumber();
            case "bic" -> party.getBic();
            case "bicfi" -> party.getBicfi();
            case "lei" -> party.getLei();
            case "organizationid", "organization_id" -> party.getOrganizationId();
            case "privateid", "private_id" -> party.getPrivateId();
            case "role" -> party.getRole();
            default -> null;
        };
    }

    private Object getAmountField(Amount amount, String fieldName) {
        return switch (fieldName.toLowerCase()) {
            case "value", "amount" -> amount.getValue();
            case "currency" -> amount.getCurrency();
            case "type" -> amount.getType();
            case "decimalplaces", "decimal_places" -> amount.getDecimalPlaces();
            default -> null;
        };
    }

    private Object getHeaderField(com.swift.translator.domain.model.canonical.MessageHeader header, String fieldName) {
        return switch (fieldName.toLowerCase()) {
            case "messageid", "message_id" -> header.getMessageId();
            case "senderbic", "sender_bic" -> header.getSenderBic();
            case "receiverbic", "receiver_bic" -> header.getReceiverBic();
            case "priority" -> header.getPriority();
            case "applicationid", "application_id" -> header.getApplicationId();
            case "serviceid", "service_id" -> header.getServiceId();
            case "sessionnumber", "session_number" -> header.getSessionNumber();
            case "sequencenumber", "sequence_number" -> header.getSequenceNumber();
            default -> null;
        };
    }

    private Object getTransactionField(com.swift.translator.domain.model.canonical.Transaction transaction, String fieldName) {
        return switch (fieldName.toLowerCase()) {
            case "transactionreference", "transaction_reference" -> transaction.getTransactionReference();
            case "relatedreference", "related_reference" -> transaction.getRelatedReference();
            case "valuedate", "value_date" -> transaction.getValueDate();
            case "transactiontype", "transaction_type" -> transaction.getTransactionType();
            case "purposecode", "purpose_code" -> transaction.getPurposeCode();
            case "chargebearer", "charge_bearer" -> transaction.getChargeBearer();
            case "instructioncode", "instruction_code" -> transaction.getInstructionCode();
            case "servicelevel", "service_level" -> transaction.getServiceLevel();
            case "localinstrument", "local_instrument" -> transaction.getLocalInstrument();
            case "clearingchannel", "clearing_channel" -> transaction.getClearingChannel();
            default -> null;
        };
    }

    /**
     * Compares two values numerically if possible, otherwise lexicographically.
     */
    @SuppressWarnings("unchecked")
    private int compareValues(Object left, Object right) {
        if (left == null && right == null) return 0;
        if (left == null) return -1;
        if (right == null) return 1;

        // Try numeric comparison
        try {
            BigDecimal leftNum = new BigDecimal(left.toString());
            BigDecimal rightNum = new BigDecimal(right.toString());
            return leftNum.compareTo(rightNum);
        } catch (NumberFormatException e) {
            // Fall back to string comparison
            return left.toString().compareTo(right.toString());
        }
    }

    /**
     * Result of rule evaluation.
     */
    public record RuleResult(boolean allowed, List<RuleViolation> violations, List<String> flags) {

        public boolean hasViolations() {
            return violations != null && !violations.isEmpty();
        }

        public boolean hasErrors() {
            return violations != null && violations.stream()
                .anyMatch(v -> "ERROR".equals(v.severity()));
        }

        public boolean hasWarnings() {
            return violations != null && violations.stream()
                .anyMatch(v -> "WARNING".equals(v.severity()));
        }

        public List<String> getErrorMessages() {
            if (violations == null) return Collections.emptyList();
            return violations.stream()
                .filter(v -> "ERROR".equals(v.severity()))
                .map(RuleViolation::message)
                .toList();
        }
    }

    /**
     * Individual rule violation.
     */
    public record RuleViolation(String ruleId, String message, String severity) {}
}
