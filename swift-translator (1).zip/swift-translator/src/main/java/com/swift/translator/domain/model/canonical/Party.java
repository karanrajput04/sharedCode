package com.swift.translator.domain.model.canonical;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Singular;
import lombok.ToString;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Represents a party (debtor, creditor, intermediary, etc.) in a transaction.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class Party {

    private final PartyRole role;
    private final String name;
    private final String address;
    private final String city;
    private final String country;
    private final String postalCode;
    private final String accountNumber;
    private final String accountType;
    private final String bic;
    private final String bicfi;
    private final String clearingSystemMemberId;
    private final String clearingSystemId;
    private final String lei;
    private final String organizationId;
    private final String privateId;
    private final String dateOfBirth;
    private final String placeOfBirth;
    private final String countryOfBirth;
    private final String provinceOfBirth;
    private final String contactName;
    private final String contactPhone;
    private final String contactEmail;
    private final String contactMobile;

    @Singular
    private final Map<String, String> identification;

    @Singular
    private final List<String> addressLines;

    public List<String> getAddressLines() {
        return addressLines == null ? Collections.emptyList() : Collections.unmodifiableList(addressLines);
    }
}
