package com.swift.translator.domain.model.canonical;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.List;

/**
 * Free-form narrative text in a message.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class Narrative {

    private final String code;
    private final List<String> lines;
    private final String fullText;
}
