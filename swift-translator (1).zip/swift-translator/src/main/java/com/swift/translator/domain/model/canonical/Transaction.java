package com.swift.translator.domain.model.canonical;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Core transaction details extracted from any message format.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class Transaction {

    private final String transactionReference;
    private final String relatedReference;
    private final LocalDate valueDate;
    private final LocalDateTime creationDateTime;
    private final String transactionType;
    private final String purposeCode;
    private final String categoryPurpose;
    private final String localInstrument;
    private final String serviceLevel;
    private final String clearingChannel;
    private final String chargeBearer;
    private final String instructionCode;
    private final String transactionStatus;
    private final String acceptanceDateTime;
    private final String requestedExecutionDate;
    private final String interbankSettlementDate;
    private final String interbankSettlementCurrency;
    private final String instructedCurrency;
}
