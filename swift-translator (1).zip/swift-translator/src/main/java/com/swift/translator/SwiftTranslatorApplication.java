package com.swift.translator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Enterprise MT ↔ MX Translation Platform.
 * 
 * <p>Production-grade application for bidirectional translation between SWIFT MT 
 * (legacy text format) and MX (ISO 20022 XML format) messages.</p>
 * 
 * <p>Features:
 * <ul>
 *   <li>Configuration-driven mapping engine (no hardcoded rules)</li>
 *   <li>Support for MT103, MT202, MT540-MT548, MT900, MT950 and MX equivalents</li>
 *   <li>High throughput: 10,000+ messages/second per node</li>
 *   <li>Comprehensive validation (schema, business, SWIFT rules)</li>
 *   <li>Enterprise observability with correlation IDs and distributed tracing</li>
 * </ul>
 * 
 * @author Swift Translator Team
 * @version 1.0.0
 * @since 2024
 */
@SpringBootApplication
@EnableCaching
@EnableAsync
public class SwiftTranslatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(SwiftTranslatorApplication.class, args);
    }
}
