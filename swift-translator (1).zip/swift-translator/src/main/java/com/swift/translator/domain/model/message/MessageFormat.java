package com.swift.translator.domain.model.message;

/**
 * Enumeration of supported message formats in the translation platform.
 * 
 * <p>Each format represents a distinct wire format that can be parsed into
 * the canonical model and serialized from the canonical model.</p>
 */
public enum MessageFormat {
    /** SWIFT MT (Message Type) - Legacy fixed-length text format */
    MT,

    /** SWIFT MX - ISO 20022 XML format */
    MX,

    /** Generic XML format */
    XML,

    /** JSON format */
    JSON,

    /** Comma-separated values */
    CSV,

    /** Generic delimited text */
    TEXT,

    /** Internal canonical representation */
    CANONICAL
}
