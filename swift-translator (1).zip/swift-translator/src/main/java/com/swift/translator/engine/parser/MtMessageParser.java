package com.swift.translator.engine.parser;

import com.swift.translator.domain.model.canonical.*;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ParsingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pure Java parser for SWIFT MT (Message Type) messages.
 * 
 * <p>No external dependencies - implements full MT parsing natively.</p>
 * <p>Supports MT103, MT202, MT540-MT548, MT900, MT910, MT950 and variants.</p>
 */
@Slf4j
@Component
public class MtMessageParser implements MessageParser {

    private static final DateTimeFormatter MT_DATE_FORMAT = DateTimeFormatter.ofPattern("yyMMdd");

    // MT Block patterns
    private static final Pattern BLOCK1_PATTERN = Pattern.compile(
        "\{1:(F|L)?(01|21)([A-Z]{12})([0-9]{4})([0-9]{6})([A-Z0-9]{4})([0-9]{6})([0-9]{4})([A-Z])?\}"
    );
    private static final Pattern BLOCK2_INPUT_PATTERN = Pattern.compile(
        "\{2:I([0-9]{3})([A-Z0-9]{4})([A-Z])([0-9])?([0-9])?\}"
    );
    private static final Pattern BLOCK2_OUTPUT_PATTERN = Pattern.compile(
        "\{2:O([0-9]{3})([0-9]{4})([0-9]{6})([A-Z0-9]{12})([0-9]{4})([0-9]{6})([A-Z0-9]{4})([0-9]{6})([0-9]{4})\}"
    );
    private static final Pattern BLOCK4_PATTERN = Pattern.compile(
        "\{4:([^}]*)\}"
    );
    private static final Pattern BLOCK5_PATTERN = Pattern.compile(
        "\{5:([^}]*)\}"
    );
    private static final Pattern TAG_PATTERN = Pattern.compile(
        ":([0-9]{2}[A-Z]?):(.*?)\n(?=:[0-9]{2}[A-Z]?:|$)"
    );

    @Override
    public boolean supports(MessageType messageType) {
        return messageType != null && messageType.isMt();
    }

    @Override
    public CanonicalMessage parse(String content, MessageType messageType, MessageMetadata metadata) {
        log.debug("Parsing MT message type: {}, correlationId: {}", 
            messageType.getTypeCode(), metadata.getCorrelationId());

        try {
            MtMessage mtMessage = parseMtMessage(content);
            return buildCanonicalMessage(mtMessage, messageType, metadata);
        } catch (ParsingException e) {
            throw e;
        } catch (Exception e) {
            throw new ParsingException("Failed to parse MT message: " + e.getMessage(), e,
                "MT_PARSE_ERROR", metadata);
        }
    }

    /**
     * Parses raw MT text into structured MT message.
     */
    private MtMessage parseMtMessage(String content) {
        MtMessage mt = new MtMessage();

        // Parse Block 1 (Basic Header)
        Matcher block1Matcher = BLOCK1_PATTERN.matcher(content);
        if (block1Matcher.find()) {
            mt.block1 = new Block1();
            mt.block1.applicationId = block1Matcher.group(1);
            mt.block1.serviceId = block1Matcher.group(2);
            mt.block1.logicalTerminal = block1Matcher.group(3);
            mt.block1.sessionNumber = block1Matcher.group(7);
            mt.block1.sequenceNumber = block1Matcher.group(8);
        }

        // Parse Block 2 (Application Header)
        Matcher block2InputMatcher = BLOCK2_INPUT_PATTERN.matcher(content);
        Matcher block2OutputMatcher = BLOCK2_OUTPUT_PATTERN.matcher(content);

        if (block2InputMatcher.find()) {
            mt.block2 = new Block2();
            mt.block2.messageType = block2InputMatcher.group(1);
            mt.block2.receiverAddress = block2InputMatcher.group(2);
            mt.block2.messagePriority = block2InputMatcher.group(3);
            mt.block2.deliveryMonitoring = block2InputMatcher.group(4);
            mt.block2.obsolescencePeriod = block2InputMatcher.group(5);
            mt.block2.inputOutput = "I";
        } else if (block2OutputMatcher.find()) {
            mt.block2 = new Block2();
            mt.block2.messageType = block2OutputMatcher.group(1);
            mt.block2.inputOutput = "O";
            mt.block2.date = block2OutputMatcher.group(2);
            mt.block2.time = block2OutputMatcher.group(3);
            mt.block2.mir = block2OutputMatcher.group(4);
            mt.block2.sessionNumber = block2OutputMatcher.group(5);
            mt.block2.dateOut = block2OutputMatcher.group(6);
            mt.block2.timeOut = block2OutputMatcher.group(7);
        }

        // Parse Block 4 (Text)
        Matcher block4Matcher = BLOCK4_PATTERN.matcher(content);
        if (block4Matcher.find()) {
            String block4Content = block4Matcher.group(1);
            mt.block4 = parseBlock4(block4Content);
        }

        // Parse Block 5 (Trailers)
        Matcher block5Matcher = BLOCK5_PATTERN.matcher(content);
        if (block5Matcher.find()) {
            String block5Content = block5Matcher.group(1);
            mt.block5 = parseBlock5(block5Content);
        }

        return mt;
    }

    private Map<String, String> parseBlock4(String content) {
        Map<String, String> tags = new LinkedHashMap<>();

        // Split by newline and parse tags
        String[] lines = content.split("\n");
        String currentTag = null;
        StringBuilder currentValue = new StringBuilder();

        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) continue;

            // Check if line starts a new tag
            if (line.matches(":([0-9]{2}[A-Z]?):.*")) {
                // Save previous tag
                if (currentTag != null) {
                    tags.put(currentTag, currentValue.toString().trim());
                }

                // Extract tag name and value
                int colonIndex = line.indexOf(':', 1);
                currentTag = line.substring(1, colonIndex);
                currentValue = new StringBuilder(line.substring(colonIndex + 1));
            } else {
                // Continue previous tag value
                if (currentTag != null) {
                    currentValue.append("\n").append(line);
                }
            }
        }

        // Save last tag
        if (currentTag != null) {
            tags.put(currentTag, currentValue.toString().trim());
        }

        return tags;
    }

    private Map<String, String> parseBlock5(String content) {
        Map<String, String> tags = new LinkedHashMap<>();

        // Parse trailer tags like {CHK:...}, {MAC:...}
        Pattern trailerPattern = Pattern.compile("\{([A-Z]{3}):([^}]*)\}");
        Matcher matcher = trailerPattern.matcher(content);

        while (matcher.find()) {
            tags.put(matcher.group(1), matcher.group(2));
        }

        return tags;
    }

    private CanonicalMessage buildCanonicalMessage(MtMessage mt, MessageType messageType, 
                                                   MessageMetadata metadata) {
        CanonicalMessage.CanonicalMessageBuilder builder = CanonicalMessage.builder();

        builder.header(parseHeader(mt, messageType));
        builder.transaction(parseTransaction(mt, metadata));
        builder.parties(parseParties(mt, metadata));
        builder.amounts(parseAmounts(mt, metadata));
        builder.references(parseReferences(mt, metadata));
        builder.narratives(parseNarratives(mt, metadata));
        builder.control(parseControlBlock(mt));

        if (mt.block4 != null) {
            builder.rawPayload(String.join("\n", mt.block4.values()));
        }

        return builder.build();
    }

    private MessageHeader parseHeader(MtMessage mt, MessageType messageType) {
        MessageHeader.MessageHeaderBuilder header = MessageHeader.builder()
            .messageType(messageType);

        if (mt.block1 != null) {
            header.senderBic(mt.block1.logicalTerminal);
            header.applicationId(mt.block1.applicationId);
            header.serviceId(mt.block1.serviceId);
            header.sessionNumber(mt.block1.sessionNumber);
            header.sequenceNumber(mt.block1.sequenceNumber);
        }

        if (mt.block2 != null) {
            header.receiverBic(mt.block2.receiverAddress);
            header.priority(mt.block2.messagePriority);
            header.deliveryMonitoring(mt.block2.deliveryMonitoring);
            header.obsolescencePeriod(mt.block2.obsolescencePeriod);
            if (mt.block2.mir != null) {
                header.messageId(mt.block2.mir);
                header.networkReference(mt.block2.mir);
            }
        }

        return header.build();
    }

    private Transaction parseTransaction(MtMessage mt, MessageMetadata metadata) {
        Transaction.TransactionBuilder transaction = Transaction.builder();

        if (mt.block4 != null) {
            getTagValue(mt.block4, "20").ifPresent(transaction::transactionReference);
            getTagValue(mt.block4, "21").ifPresent(transaction::relatedReference);

            getTagValue(mt.block4, "32A").ifPresent(val -> parseTag32A(val, transaction));
            getTagValue(mt.block4, "32B").ifPresent(val -> parseTag32B(val, transaction));
            getTagValue(mt.block4, "33B").ifPresent(val -> parseTag33B(val, transaction));

            getTagValue(mt.block4, "71A").ifPresent(transaction::chargeBearer);
            getTagValue(mt.block4, "23B").ifPresent(transaction::transactionType);
            getTagValue(mt.block4, "23E").ifPresent(transaction::instructionCode);
            getTagValue(mt.block4, "23F").ifPresent(transaction::categoryPurpose);
            getTagValue(mt.block4, "13C").ifPresent(transaction::clearingChannel);
        }

        return transaction.build();
    }

    private void parseTag32A(String value, Transaction.TransactionBuilder transaction) {
        try {
            if (value.length() >= 6) {
                LocalDate date = LocalDate.parse(value.substring(0, 6), MT_DATE_FORMAT);
                transaction.valueDate(date);
            }
            if (value.length() >= 9) {
                transaction.interbankSettlementCurrency(value.substring(6, 9));
            }
        } catch (DateTimeParseException e) {
            log.warn("Failed to parse date from tag 32A: {}", value);
        }
    }

    private void parseTag32B(String value, Transaction.TransactionBuilder transaction) {
        // Format: CCYAMOUNT
        if (value.length() >= 3) {
            transaction.interbankSettlementCurrency(value.substring(0, 3));
        }
    }

    private void parseTag33B(String value, Transaction.TransactionBuilder transaction) {
        // Format: CCYAMOUNT (instructed amount)
        if (value.length() >= 3) {
            transaction.instructedCurrency(value.substring(0, 3));
        }
    }

    private List<Party> parseParties(MtMessage mt, MessageMetadata metadata) {
        List<Party> parties = new ArrayList<>();

        if (mt.block4 == null) return parties;

        // Ordering Customer (tag 50a)
        parseParty(mt.block4, "50", PartyRole.ORDERING_CUSTOMER).ifPresent(parties::add);

        // Ordering Institution (tag 51a)
        parseParty(mt.block4, "51", PartyRole.ORDERING_INSTITUTION).ifPresent(parties::add);

        // Sender's Correspondent (tag 53a)
        parseParty(mt.block4, "53", PartyRole.SENDER_CORRESPONDENT).ifPresent(parties::add);

        // Receiver's Correspondent (tag 54a)
        parseParty(mt.block4, "54", PartyRole.RECEIVER_CORRESPONDENT).ifPresent(parties::add);

        // Third Reimbursement Institution (tag 55a)
        parseParty(mt.block4, "55", PartyRole.THIRD_REIMBURSEMENT_AGENT).ifPresent(parties::add);

        // Intermediary (tag 56a)
        parseParty(mt.block4, "56", PartyRole.INTERMEDIARY_AGENT_1).ifPresent(parties::add);

        // Account With Institution (tag 57a)
        parseParty(mt.block4, "57", PartyRole.CREDITOR_AGENT).ifPresent(parties::add);

        // Beneficiary (tag 59a)
        parseParty(mt.block4, "59", PartyRole.BENEFICIARY).ifPresent(parties::add);

        // Remittance Information (tag 70)
        getTagValue(mt.block4, "70").ifPresent(val -> {
            parties.add(Party.builder()
                .role(PartyRole.REMITTANCE_INFORMATION)
                .name(val)
                .build());
        });

        return parties;
    }

    private Optional<Party> parseParty(Map<String, String> block4, String tagPrefix, PartyRole role) {
        // Try different option letters (A, B, C, D, F, J, K)
        for (char option : new char[]{'A', 'B', 'C', 'D', 'F', 'J', 'K'}) {
            String tagName = tagPrefix + option;
            Optional<String> value = getTagValue(block4, tagName);
            if (value.isPresent()) {
                return Optional.of(buildParty(value.get(), role, tagName));
            }
        }

        // Try without option letter
        return getTagValue(block4, tagPrefix).map(v -> buildParty(v, tagPrefix, role));
    }

    private Party buildParty(String rawValue, PartyRole role, String tagName) {
        Party.PartyBuilder party = Party.builder().role(role);

        if (tagName.endsWith("A")) {
            // Option A: [/Account]
BIC
            String[] parts = rawValue.split("\n", 2);
            if (parts.length > 1) {
                party.accountNumber(parts[0].replace("/", "").trim());
                party.bic(parts[1].trim());
            } else {
                party.bic(rawValue.trim());
            }
        } else if (tagName.endsWith("B")) {
            // Option B: Location
            party.name(rawValue.trim());
        } else if (tagName.endsWith("C")) {
            // Option C: Party Identifier
            party.name(rawValue.trim());
        } else if (tagName.endsWith("D") || tagName.endsWith("K")) {
            // Option D/K: [/Account]
Name
Address
City
Country
            String[] parts = rawValue.split("\n", 5);
            if (parts.length >= 1) {
                party.accountNumber(parts[0].replace("/", "").trim());
            }
            if (parts.length >= 2) {
                party.name(parts[1].trim());
            }
            if (parts.length >= 3) {
                party.address(parts[2].trim());
            }
            if (parts.length >= 4) {
                party.city(parts[3].trim());
            }
            if (parts.length >= 5) {
                party.country(parts[4].trim());
            }
        } else if (tagName.endsWith("F")) {
            // Option F: Structured format
            party.name(rawValue.trim());
        } else if (tagName.endsWith("J")) {
            // Option J: Structured name and address
            party.name(rawValue.trim());
        } else {
            // No option or unknown
            party.name(rawValue.trim());
        }

        return party.build();
    }

    private Party buildParty(String rawValue, String tagPrefix, PartyRole role) {
        return buildParty(rawValue, role, tagPrefix + "D");
    }

    private List<Amount> parseAmounts(MtMessage mt, MessageMetadata metadata) {
        List<Amount> amounts = new ArrayList<>();

        if (mt.block4 == null) return amounts;

        // Tag 32A - Interbank Settlement Amount
        getTagValue(mt.block4, "32A").ifPresent(val -> {
            try {
                if (val.length() >= 9) {
                    String currency = val.substring(6, 9);
                    String amountStr = val.substring(9).replace(",", ".");
                    BigDecimal amount = new BigDecimal(amountStr);
                    amounts.add(Amount.builder()
                        .type(AmountType.INTERBANK_SETTLEMENT)
                        .value(amount)
                        .currency(currency)
                        .build());
                }
            } catch (Exception e) {
                log.warn("Failed to parse amount from tag 32A: {}", val);
            }
        });

        // Tag 32B - Currency/Amount
        getTagValue(mt.block4, "32B").ifPresent(val -> {
            try {
                if (val.length() >= 3) {
                    String currency = val.substring(0, 3);
                    String amountStr = val.substring(3).replace(",", ".");
                    BigDecimal amount = new BigDecimal(amountStr);
                    amounts.add(Amount.builder()
                        .type(AmountType.INTERBANK_SETTLEMENT)
                        .value(amount)
                        .currency(currency)
                        .build());
                }
            } catch (Exception e) {
                log.warn("Failed to parse amount from tag 32B: {}", val);
            }
        });

        // Tag 33B - Currency/Instructed Amount
        getTagValue(mt.block4, "33B").ifPresent(val -> {
            try {
                if (val.length() >= 3) {
                    String currency = val.substring(0, 3);
                    String amountStr = val.substring(3).replace(",", ".");
                    BigDecimal amount = new BigDecimal(amountStr);
                    amounts.add(Amount.builder()
                        .type(AmountType.INSTRUCTED)
                        .value(amount)
                        .currency(currency)
                        .build());
                }
            } catch (Exception e) {
                log.warn("Failed to parse amount from tag 33B: {}", val);
            }
        });

        // Tag 34B - Total Amount
        getTagValue(mt.block4, "34B").ifPresent(val -> {
            try {
                if (val.length() >= 3) {
                    String currency = val.substring(0, 3);
                    String amountStr = val.substring(3).replace(",", ".");
                    BigDecimal amount = new BigDecimal(amountStr);
                    amounts.add(Amount.builder()
                        .type(AmountType.COUNTER_VALUE)
                        .value(amount)
                        .currency(currency)
                        .build());
                }
            } catch (Exception e) {
                log.warn("Failed to parse amount from tag 34B: {}", val);
            }
        });

        return amounts;
    }

    private List<Reference> parseReferences(MtMessage mt, MessageMetadata metadata) {
        List<Reference> references = new ArrayList<>();

        if (mt.block4 == null) return references;

        getTagValue(mt.block4, "20").ifPresent(v -> references.add(Reference.builder()
            .type("TRANSACTION_REFERENCE")
            .value(v)
            .build()));

        getTagValue(mt.block4, "21").ifPresent(v -> references.add(Reference.builder()
            .type("RELATED_REFERENCE")
            .value(v)
            .build()));

        getTagValue(mt.block4, "26T").ifPresent(v -> references.add(Reference.builder()
            .type("TYPE_NUMBER")
            .value(v)
            .build()));

        return references;
    }

    private List<Narrative> parseNarratives(MtMessage mt, MessageMetadata metadata) {
        List<Narrative> narratives = new ArrayList<>();

        if (mt.block4 == null) return narratives;

        getTagValue(mt.block4, "70").ifPresent(v -> narratives.add(Narrative.builder()
            .code("REMITTANCE_INFO")
            .fullText(v)
            .lines(Arrays.asList(v.split("\n")))
            .build()));

        getTagValue(mt.block4, "71B").ifPresent(v -> narratives.add(Narrative.builder()
            .code("DETAILS_OF_CHARGES")
            .fullText(v)
            .lines(Arrays.asList(v.split("\n")))
            .build()));

        getTagValue(mt.block4, "72").ifPresent(v -> narratives.add(Narrative.builder()
            .code("SENDER_TO_RECEIVER")
            .fullText(v)
            .lines(Arrays.asList(v.split("\n")))
            .build()));

        getTagValue(mt.block4, "77B").ifPresent(v -> narratives.add(Narrative.builder()
            .code("REGULATORY_REPORTING")
            .fullText(v)
            .lines(Arrays.asList(v.split("\n")))
            .build()));

        getTagValue(mt.block4, "77T").ifPresent(v -> narratives.add(Narrative.builder()
            .code("ENVELOPE_CONTENTS")
            .fullText(v)
            .lines(Arrays.asList(v.split("\n")))
            .build()));

        return narratives;
    }

    private ControlBlock parseControlBlock(MtMessage mt) {
        ControlBlock.ControlBlockBuilder control = ControlBlock.builder();

        if (mt.block5 != null) {
            if (mt.block5.containsKey("MAC")) {
                control.mac(mt.block5.get("MAC"));
            }
            if (mt.block5.containsKey("CHK")) {
                control.chk(mt.block5.get("CHK"));
            }
            if (mt.block5.containsKey("PDE")) {
                control.pdm(mt.block5.get("PDE"));
            }
            if (mt.block5.containsKey("PDM")) {
                control.pdm(mt.block5.get("PDM"));
            }
            if (mt.block5.containsKey("MRF")) {
                control.mir(mt.block5.get("MRF"));
            }
            if (mt.block5.containsKey("TRN")) {
                control.messageUserReference(mt.block5.get("TRN"));
            }
            if (mt.block5.containsKey("SYS")) {
                control.serviceTypeIdentifier(mt.block5.get("SYS"));
            }
        }

        if (mt.block2 != null && mt.block2.mir != null) {
            control.mur(mt.block2.mir);
        }

        return control.build();
    }

    private Optional<String> getTagValue(Map<String, String> block4, String tagName) {
        if (block4 == null) return Optional.empty();
        String value = block4.get(tagName);
        if (value != null && !value.trim().isEmpty()) {
            return Optional.of(value.trim());
        }
        return Optional.empty();
    }

    @Override
    public String getFormat() {
        return "MT";
    }

    // Inner classes for MT message structure
    private static class MtMessage {
        Block1 block1;
        Block2 block2;
        Map<String, String> block4;
        Map<String, String> block5;
    }

    private static class Block1 {
        String applicationId;
        String serviceId;
        String logicalTerminal;
        String sessionNumber;
        String sequenceNumber;
    }

    private static class Block2 {
        String inputOutput;
        String messageType;
        String receiverAddress;
        String messagePriority;
        String deliveryMonitoring;
        String obsolescencePeriod;
        String date;
        String time;
        String mir;
        String dateOut;
        String timeOut;
        String sessionNumber;
    }
}
