package com.swift.translator.engine.transformer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Registry of built-in transformation functions.
 * 
 * <p>All functions are thread-safe and stateless.</p>
 */
@Slf4j
@Component
public class FunctionRegistry {

    private final Map<String, Function<List<Object>, Object>> functions = new ConcurrentHashMap<>();
    private final Map<String, CustomFunctionProvider> customFunctions = new ConcurrentHashMap<>();

    public FunctionRegistry() {
        registerBuiltinFunctions();
    }

    private void registerBuiltinFunctions() {
        // String functions
        functions.put("substring", args -> {
            String value = toString(args.get(0));
            int start = toInt(args.get(1));
            int end = args.size() > 2 ? toInt(args.get(2)) : value.length();
            return value.substring(start, Math.min(end, value.length()));
        });

        functions.put("replace", args -> {
            String value = toString(args.get(0));
            String regex = toString(args.get(1));
            String replacement = toString(args.get(2));
            return value.replaceAll(regex, replacement);
        });

        functions.put("split", args -> {
            String value = toString(args.get(0));
            String delimiter = toString(args.get(1));
            return Arrays.asList(value.split(delimiter));
        });

        functions.put("join", args -> {
            @SuppressWarnings("unchecked")
            List<String> list = (List<String>) args.get(0);
            String delimiter = toString(args.get(1));
            return String.join(delimiter, list);
        });

        functions.put("trim", args -> toString(args.get(0)).trim());
        functions.put("uppercase", args -> toString(args.get(0)).toUpperCase());
        functions.put("lowercase", args -> toString(args.get(0)).toLowerCase());

        functions.put("format", args -> {
            String value = toString(args.get(0));
            String pattern = toString(args.get(1));
            DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
            DecimalFormat df = new DecimalFormat(pattern, symbols);
            return df.format(new BigDecimal(value));
        });

        // Date functions
        functions.put("dateConvert", args -> {
            String value = toString(args.get(0));
            String sourceFormat = toString(args.get(1));
            String targetFormat = toString(args.get(2));
            try {
                DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern(sourceFormat);
                DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern(targetFormat);
                LocalDateTime dateTime;
                if (sourceFormat.contains("H") || sourceFormat.contains("h")) {
                    dateTime = LocalDateTime.parse(value, sourceFormatter);
                } else {
                    dateTime = LocalDate.parse(value, sourceFormatter).atStartOfDay();
                }
                return dateTime.format(targetFormatter);
            } catch (DateTimeParseException e) {
                log.warn("Failed to convert date: {} from {} to {}", value, sourceFormat, targetFormat);
                return value;
            }
        });

        functions.put("dateFormat", args -> {
            String value = toString(args.get(0));
            String format = toString(args.get(1));
            try {
                LocalDateTime dateTime = LocalDateTime.parse(value);
                return dateTime.format(DateTimeFormatter.ofPattern(format));
            } catch (DateTimeParseException e) {
                try {
                    LocalDate date = LocalDate.parse(value);
                    return date.format(DateTimeFormatter.ofPattern(format));
                } catch (DateTimeParseException e2) {
                    log.warn("Failed to format date: {}", value);
                    return value;
                }
            }
        });

        // Amount functions
        functions.put("amountFormat", args -> {
            BigDecimal amount = new BigDecimal(toString(args.get(0)));
            String currency = args.size() > 1 ? toString(args.get(1)) : "";
            DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
            DecimalFormat df = new DecimalFormat("#,##0.00", symbols);
            return df.format(amount);
        });

        functions.put("currencyConvert", args -> {
            BigDecimal amount = new BigDecimal(toString(args.get(0)));
            String fromCurrency = toString(args.get(1));
            String toCurrency = toString(args.get(2));
            BigDecimal rate = new BigDecimal(toString(args.get(3)));
            return amount.multiply(rate).setScale(2, RoundingMode.HALF_UP);
        });

        // Regex functions
        functions.put("regex", args -> {
            String value = toString(args.get(0));
            String pattern = toString(args.get(1));
            int group = args.size() > 2 ? toInt(args.get(2)) : 0;
            Pattern p = Pattern.compile(pattern);
            Matcher m = p.matcher(value);
            if (m.find() && group <= m.groupCount()) {
                return m.group(group);
            }
            return "";
        });

        functions.put("regexMatch", args -> {
            String value = toString(args.get(0));
            String pattern = toString(args.get(1));
            return Pattern.compile(pattern).matcher(value).matches();
        });

        // Padding functions
        functions.put("padLeft", args -> {
            String value = toString(args.get(0));
            int length = toInt(args.get(1));
            String padChar = args.size() > 2 ? toString(args.get(2)) : " ";
            return String.format("%" + length + "s", value).replace(' ', padChar.charAt(0));
        });

        functions.put("padRight", args -> {
            String value = toString(args.get(0));
            int length = toInt(args.get(1));
            String padChar = args.size() > 2 ? toString(args.get(2)) : " ";
            return String.format("%-" + length + "s", value).replace(' ', padChar.charAt(0));
        });

        // Lookup function (placeholder - would integrate with reference data service)
        functions.put("lookup", args -> {
            String table = toString(args.get(0));
            String key = toString(args.get(1));
            log.debug("Lookup in table {} for key {}", table, key);
            // In production, this would query a reference data cache
            return key;
        });

        // Concatenation
        functions.put("concatenate", args -> {
            StringBuilder sb = new StringBuilder();
            for (Object arg : args) {
                sb.append(toString(arg));
            }
            return sb.toString();
        });

        // Conditional
        functions.put("ifElse", args -> {
            boolean condition = Boolean.parseBoolean(toString(args.get(0)));
            return condition ? args.get(1) : args.get(2);
        });

        // Coalesce
        functions.put("coalesce", args -> {
            for (Object arg : args) {
                if (arg != null && !toString(arg).isEmpty()) {
                    return arg;
                }
            }
            return "";
        });
    }

    /**
     * Executes a function by name with given arguments.
     */
    public Object execute(String functionName, List<Object> arguments) {
        Function<List<Object>, Object> function = functions.get(functionName);
        if (function == null) {
            CustomFunctionProvider custom = customFunctions.get(functionName);
            if (custom != null) {
                return custom.execute(arguments);
            }
            throw new IllegalArgumentException("Unknown function: " + functionName);
        }
        return function.apply(arguments);
    }

    /**
     * Registers a custom function.
     */
    public void registerFunction(String name, Function<List<Object>, Object> function) {
        functions.put(name, function);
        log.info("Registered custom function: {}", name);
    }

    /**
     * Registers a custom function provider.
     */
    public void registerCustomProvider(String name, CustomFunctionProvider provider) {
        customFunctions.put(name, provider);
        log.info("Registered custom function provider: {}", name);
    }

    /**
     * Checks if a function exists.
     */
    public boolean hasFunction(String name) {
        return functions.containsKey(name) || customFunctions.containsKey(name);
    }

    private String toString(Object obj) {
        return obj == null ? "" : obj.toString();
    }

    private int toInt(Object obj) {
        if (obj instanceof Number) {
            return ((Number) obj).intValue();
        }
        return Integer.parseInt(toString(obj));
    }

    /**
     * Interface for custom function providers.
     */
    public interface CustomFunctionProvider {
        Object execute(List<Object> arguments);
    }
}
