package com.swift.translator.engine.serializer;

import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ParsingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Factory for creating appropriate serializer based on target message type.
 */
@Slf4j
@Component
public class SerializerFactory {

    private final List<MessageSerializer> serializers;
    private final Map<MessageType, MessageSerializer> serializerCache;

    public SerializerFactory(List<MessageSerializer> serializers) {
        this.serializers = serializers;
        this.serializerCache = new ConcurrentHashMap<>();
    }

    /**
     * Gets the appropriate serializer for the given message type.
     */
    public MessageSerializer getSerializer(MessageType messageType) {
        return serializerCache.computeIfAbsent(messageType, type -> {
            for (MessageSerializer serializer : serializers) {
                if (serializer.supports(type)) {
                    log.debug("Selected serializer {} for message type {}", 
                        serializer.getClass().getSimpleName(), type);
                    return serializer;
                }
            }
            throw new ParsingException("No serializer found for message type: " + type, 
                "SERIALIZER_NOT_FOUND", null);
        });
    }

    /**
     * Registers a new serializer (for plugin architecture).
     */
    public void registerSerializer(MessageSerializer serializer) {
        serializers.add(serializer);
        serializerCache.clear();
        log.info("Registered serializer: {}", serializer.getClass().getSimpleName());
    }
}
