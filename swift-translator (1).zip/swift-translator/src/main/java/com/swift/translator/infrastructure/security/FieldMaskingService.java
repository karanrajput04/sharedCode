package com.swift.translator.infrastructure.security;

import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Service for masking sensitive fields in messages.
 * 
 * <p>Masks account numbers, amounts, and other PII data for logging and display.</p>
 */
@Service
public class FieldMaskingService {

    private static final Pattern ACCOUNT_PATTERN = Pattern.compile("(/[0-9]{4})[0-9]{4,}([0-9]{4})");
    private static final Pattern IBAN_PATTERN = Pattern.compile("([A-Z]{2}[0-9]{2})[A-Z0-9]{10,}([A-Z0-9]{4})");
    private static final Pattern AMOUNT_PATTERN = Pattern.compile("([0-9]{1,3})[,\.][0-9]{2}");
    private static final Pattern BIC_PATTERN = Pattern.compile("([A-Z]{4})([A-Z0-9]{2})([A-Z0-9]{0,3})");

    /**
     * Masks sensitive data in a message for logging.
     */
    public String maskForLogging(String message) {
        if (message == null || message.isEmpty()) {
            return message;
        }

        String masked = message;

        // Mask account numbers: /1234****5678
        masked = ACCOUNT_PATTERN.matcher(masked).replaceAll("$1****$2");

        // Mask IBANs: GB12****1234
        masked = IBAN_PATTERN.matcher(masked).replaceAll("$1****$2");

        // Mask amounts: 1***.00
        masked = AMOUNT_PATTERN.matcher(masked).replaceAll("****.00");

        return masked;
    }

    /**
     * Masks a specific field value.
     */
    public String maskField(String fieldName, String value) {
        if (value == null) return null;

        return switch (fieldName.toLowerCase()) {
            case "account", "accountnumber", "iban" -> maskAccount(value);
            case "amount", "value" -> maskAmount(value);
            case "bic", "bicfi" -> maskBic(value);
            case "password", "secret", "token" -> "********";
            default -> value;
        };
    }

    private String maskAccount(String account) {
        if (account.length() <= 8) {
            return "****";
        }
        return account.substring(0, 4) + "****" + account.substring(account.length() - 4);
    }

    private String maskAmount(String amount) {
        return "****.00";
    }

    private String maskBic(String bic) {
        if (bic.length() < 6) return bic;
        return bic.substring(0, 4) + "**" + (bic.length() > 6 ? bic.substring(6) : "");
    }
}
