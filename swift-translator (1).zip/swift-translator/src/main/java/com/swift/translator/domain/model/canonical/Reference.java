package com.swift.translator.domain.model.canonical;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * A reference number or identifier in a message.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class Reference {

    private final String type;
    private final String value;
    private final String issuer;
    private final String proprietaryType;
}
