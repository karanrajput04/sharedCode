package com.swift.translator.engine.validator;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Comprehensive validation engine supporting multiple validation types:
 * - Schema validation (XSD for MX, SWIFT rules for MT)
 * - Business validation (custom rules)
 * - SWIFT network validation rules
 * - ISO 20022 validation
 * - Custom validation
 */
@Slf4j
@Component
public class ValidationEngine {

    private final List<Validator> validators;

    public ValidationEngine(List<Validator> validators) {
        this.validators = validators;
    }

    /**
     * Validates a message using all applicable validators.
     * 
     * @param message the canonical message to validate
     * @param messageType the message type
     * @param metadata message metadata
     * @param context validation context (INPUT or OUTPUT)
     * @throws ValidationException if validation fails
     */
    public void validate(CanonicalMessage message, MessageType messageType, 
                        MessageMetadata metadata, ValidationContext context) {
        log.debug("Starting validation for {} in context {}", messageType.getTypeCode(), context);

        List<ValidationException.ValidationError> allErrors = new ArrayList<>();
        List<ValidationException.ValidationError> warnings = new ArrayList<>();

        for (Validator validator : validators) {
            if (validator.supports(messageType, context)) {
                try {
                    log.debug("Running validator: {}", validator.getName());
                    List<ValidationException.ValidationError> errors = validator.validate(message, messageType, metadata);

                    for (ValidationException.ValidationError error : errors) {
                        if ("ERROR".equals(error.getSeverity())) {
                            allErrors.add(error);
                        } else {
                            warnings.add(error);
                        }
                    }
                } catch (Exception e) {
                    log.error("Validator {} failed: {}", validator.getName(), e.getMessage(), e);
                    allErrors.add(new ValidationException.ValidationError(
                        "VALIDATOR", "VALIDATOR_ERROR", 
                        "Validator " + validator.getName() + " failed: " + e.getMessage(), "ERROR"));
                }
            }
        }

        // Add warnings to errors list for reporting
        allErrors.addAll(warnings);

        if (!allErrors.isEmpty()) {
            boolean hasErrors = allErrors.stream().anyMatch(e -> "ERROR".equals(e.getSeverity()));
            if (hasErrors) {
                throw new ValidationException(
                    "Validation failed with " + allErrors.stream().filter(e -> "ERROR".equals(e.getSeverity())).count() + " errors",
                    allErrors, "VALIDATION_FAILED", metadata);
            }
        }

        log.debug("Validation completed successfully");
    }

    /**
     * Validator interface.
     */
    public interface Validator {

        /**
         * Returns the validator name.
         */
        String getName();

        /**
         * Checks if this validator supports the given message type and context.
         */
        boolean supports(MessageType messageType, ValidationContext context);

        /**
         * Validates the message and returns a list of errors.
         */
        List<ValidationException.ValidationError> validate(CanonicalMessage message, 
                                                           MessageType messageType, 
                                                           MessageMetadata metadata);
    }

    /**
     * Validation context.
     */
    public enum ValidationContext {
        /** Validation before parsing/transformation */
        INPUT,
        /** Validation after transformation */
        OUTPUT,
        /** Schema validation */
        SCHEMA,
        /** Business rule validation */
        BUSINESS
    }
}
