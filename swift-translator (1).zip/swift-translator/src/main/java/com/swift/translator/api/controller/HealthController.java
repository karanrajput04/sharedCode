package com.swift.translator.api.controller;

import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Map;

/**
 * Health check controller for operational monitoring.
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/health")
public class HealthController {

    @GetMapping
    public ResponseEntity<HealthStatus> health() {
        return ResponseEntity.ok(HealthStatus.builder()
            .status("UP")
            .timestamp(Instant.now().toString())
            .version("1.0.0")
            .build());
    }

    @GetMapping("/ready")
    public ResponseEntity<HealthStatus> ready() {
        return ResponseEntity.ok(HealthStatus.builder()
            .status("READY")
            .timestamp(Instant.now().toString())
            .build());
    }

    @Data
    @Builder
    public static class HealthStatus {
        private String status;
        private String timestamp;
        private String version;
        private Map<String, Object> details;
    }
}
