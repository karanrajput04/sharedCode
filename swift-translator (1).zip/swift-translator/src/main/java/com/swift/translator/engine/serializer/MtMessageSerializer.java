package com.swift.translator.engine.serializer;

import com.swift.translator.domain.model.canonical.*;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ParsingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Pure Java serializer for SWIFT MT (Message Type) messages.
 * 
 * <p>No external dependencies - implements full MT serialization natively.</p>
 */
@Slf4j
@Component
public class MtMessageSerializer implements MessageSerializer {

    private static final DateTimeFormatter MT_DATE_FORMAT = DateTimeFormatter.ofPattern("yyMMdd");

    @Override
    public boolean supports(MessageType messageType) {
        return messageType != null && messageType.isMt();
    }

    @Override
    public String serialize(CanonicalMessage canonicalMessage, MessageType targetType, MessageMetadata metadata) {
        log.debug("Serializing to MT message type: {}, correlationId: {}", 
            targetType.getTypeCode(), metadata.getCorrelationId());

        try {
            StringBuilder sb = new StringBuilder();

            // Build Block 1 (Basic Header)
            buildBlock1(sb, canonicalMessage.getHeader());

            // Build Block 2 (Application Header)
            buildBlock2(sb, canonicalMessage.getHeader(), targetType);

            // Build Block 4 (Text)
            buildBlock4(sb, canonicalMessage, targetType);

            // Build Block 5 (Trailers)
            buildBlock5(sb, canonicalMessage.getControl());

            return sb.toString();

        } catch (Exception e) {
            throw new ParsingException("Failed to serialize MT message: " + e.getMessage(), e,
                "MT_SERIALIZE_ERROR", metadata);
        }
    }

    private void buildBlock1(StringBuilder sb, MessageHeader header) {
        if (header == null) return;

        sb.append("{1:");
        sb.append(header.getApplicationId() != null ? header.getApplicationId() : "F");
        sb.append(header.getServiceId() != null ? header.getServiceId() : "01");
        sb.append(header.getSenderBic() != null ? header.getSenderBic() : "UNKNOWNBICXXXX");
        sb.append("0000"); // Session number placeholder
        sb.append("000000"); // Sequence number placeholder
        sb.append("}");
    }

    private void buildBlock2(StringBuilder sb, MessageHeader header, MessageType targetType) {
        if (header == null || targetType == null) return;

        String mtType = targetType.getTypeCode().replace("MT", "");

        sb.append("{2:I");
        sb.append(mtType);
        sb.append(header.getReceiverBic() != null ? header.getReceiverBic() : "UNKNOWNBICXXXX");
        sb.append(header.getPriority() != null ? header.getPriority() : "N");
        if (header.getDeliveryMonitoring() != null) {
            sb.append(header.getDeliveryMonitoring());
        }
        if (header.getObsolescencePeriod() != null) {
            sb.append(header.getObsolescencePeriod());
        }
        sb.append("}");
    }

    private void buildBlock4(StringBuilder sb, CanonicalMessage canonicalMessage, MessageType targetType) {
        sb.append("{4:
");

        // Tag 20 - Transaction Reference Number
        if (canonicalMessage.getTransaction() != null && 
            canonicalMessage.getTransaction().getTransactionReference() != null) {
            appendTag(sb, "20", canonicalMessage.getTransaction().getTransactionReference());
        }

        // Tag 21 - Related Reference
        if (canonicalMessage.getTransaction() != null && 
            canonicalMessage.getTransaction().getRelatedReference() != null) {
            appendTag(sb, "21", canonicalMessage.getTransaction().getRelatedReference());
        }

        // Tag 23B - Bank Operation Code
        if (canonicalMessage.getTransaction() != null && 
            canonicalMessage.getTransaction().getTransactionType() != null) {
            appendTag(sb, "23B", canonicalMessage.getTransaction().getTransactionType());
        }

        // Tag 23E - Instruction Code
        if (canonicalMessage.getTransaction() != null && 
            canonicalMessage.getTransaction().getInstructionCode() != null) {
            appendTag(sb, "23E", canonicalMessage.getTransaction().getInstructionCode());
        }

        // Tag 26T - Transaction Type Code
        canonicalMessage.getReferences().stream()
            .filter(r -> "TYPE_NUMBER".equals(r.getType()))
            .findFirst()
            .ifPresent(r -> appendTag(sb, "26T", r.getValue()));

        // Tag 32A - Value Date/Currency/Interbank Settled Amount
        canonicalMessage.getInstructedAmount().ifPresent(amount -> {
            if (canonicalMessage.getTransaction() != null && 
                canonicalMessage.getTransaction().getValueDate() != null) {
                String dateStr = canonicalMessage.getTransaction().getValueDate().format(MT_DATE_FORMAT);
                String amountStr = formatMtAmount(amount.getValue());
                String tag32A = dateStr + amount.getCurrency() + amountStr;
                appendTag(sb, "32A", tag32A);
            }
        });

        // Tag 33B - Currency/Instructed Amount
        canonicalMessage.getInstructedAmount().ifPresent(amount -> {
            String amountStr = formatMtAmount(amount.getValue());
            appendTag(sb, "33B", amount.getCurrency() + amountStr);
        });

        // Tag 36 - Exchange Rate
        canonicalMessage.getAmounts().stream()
            .filter(a -> a.getExchangeRate() != null)
            .findFirst()
            .ifPresent(a -> appendTag(sb, "36", a.getExchangeRate().toPlainString()));

        // Tag 50a - Ordering Customer
        canonicalMessage.getPartyByRole(PartyRole.ORDERING_CUSTOMER).ifPresent(party -> {
            if (party.getBic() != null && !party.getBic().isEmpty()) {
                appendTag(sb, "50A", buildPartyTagValue(party));
            } else {
                appendTag(sb, "50K", buildPartyTagValue(party));
            }
        });

        // Tag 52a - Ordering Institution
        canonicalMessage.getPartyByRole(PartyRole.ORDERING_INSTITUTION).ifPresent(party -> {
            appendTag(sb, "52A", buildPartyTagValue(party));
        });

        // Tag 53a - Sender's Correspondent
        canonicalMessage.getPartyByRole(PartyRole.SENDER_CORRESPONDENT).ifPresent(party -> {
            appendTag(sb, "53A", buildPartyTagValue(party));
        });

        // Tag 54a - Receiver's Correspondent
        canonicalMessage.getPartyByRole(PartyRole.RECEIVER_CORRESPONDENT).ifPresent(party -> {
            appendTag(sb, "54A", buildPartyTagValue(party));
        });

        // Tag 55a - Third Reimbursement Institution
        canonicalMessage.getPartyByRole(PartyRole.THIRD_REIMBURSEMENT_AGENT).ifPresent(party -> {
            appendTag(sb, "55A", buildPartyTagValue(party));
        });

        // Tag 56a - Intermediary
        canonicalMessage.getPartyByRole(PartyRole.INTERMEDIARY_AGENT_1).ifPresent(party -> {
            appendTag(sb, "56A", buildPartyTagValue(party));
        });

        // Tag 57a - Account With Institution
        canonicalMessage.getPartyByRole(PartyRole.CREDITOR_AGENT).ifPresent(party -> {
            appendTag(sb, "57A", buildPartyTagValue(party));
        });

        // Tag 59a - Beneficiary Customer
        canonicalMessage.getPartyByRole(PartyRole.BENEFICIARY).ifPresent(party -> {
            if (party.getBic() != null && !party.getBic().isEmpty()) {
                appendTag(sb, "59A", buildPartyTagValue(party));
            } else {
                appendTag(sb, "59", buildPartyTagValue(party));
            }
        });

        // Tag 70 - Remittance Information
        canonicalMessage.getPartyByRole(PartyRole.REMITTANCE_INFORMATION).ifPresent(party -> {
            if (party.getName() != null) {
                appendTag(sb, "70", party.getName());
            }
        });

        // Tag 71A - Details of Charges
        if (canonicalMessage.getTransaction() != null && 
            canonicalMessage.getTransaction().getChargeBearer() != null) {
            appendTag(sb, "71A", canonicalMessage.getTransaction().getChargeBearer());
        }

        // Tag 71B - Details of Charges (if present)
        canonicalMessage.getNarratives().stream()
            .filter(n -> "DETAILS_OF_CHARGES".equals(n.getCode()))
            .findFirst()
            .ifPresent(n -> appendTag(sb, "71B", n.getFullText()));

        // Tag 72 - Sender to Receiver Information
        canonicalMessage.getNarratives().stream()
            .filter(n -> "SENDER_TO_RECEIVER".equals(n.getCode()))
            .findFirst()
            .ifPresent(n -> appendTag(sb, "72", n.getFullText()));

        // Tag 77B - Regulatory Reporting
        canonicalMessage.getNarratives().stream()
            .filter(n -> "REGULATORY_REPORTING".equals(n.getCode()))
            .findFirst()
            .ifPresent(n -> appendTag(sb, "77B", n.getFullText()));

        // Tag 77T - Envelope Contents
        canonicalMessage.getNarratives().stream()
            .filter(n -> "ENVELOPE_CONTENTS".equals(n.getCode()))
            .findFirst()
            .ifPresent(n -> appendTag(sb, "77T", n.getFullText()));

        sb.append("-}");
    }

    private void buildBlock5(StringBuilder sb, ControlBlock control) {
        if (control == null) return;

        boolean hasTrailers = control.getMac() != null || control.getChk() != null || 
                             control.getPdm() != null || control.getMir() != null ||
                             control.getMessageUserReference() != null ||
                             control.getServiceTypeIdentifier() != null;

        if (!hasTrailers) return;

        sb.append("{5:");

        if (control.getMac() != null) {
            sb.append("{MAC:").append(control.getMac()).append("}");
        }
        if (control.getChk() != null) {
            sb.append("{CHK:").append(control.getChk()).append("}");
        }
        if (control.getPdm() != null) {
            sb.append("{PDM:").append(control.getPdm()).append("}");
        }
        if (control.getMir() != null) {
            sb.append("{MRF:").append(control.getMir()).append("}");
        }
        if (control.getMessageUserReference() != null) {
            sb.append("{TRN:").append(control.getMessageUserReference()).append("}");
        }
        if (control.getServiceTypeIdentifier() != null) {
            sb.append("{SYS:").append(control.getServiceTypeIdentifier()).append("}");
        }

        sb.append("}");
    }

    private void appendTag(StringBuilder sb, String tag, String value) {
        sb.append(":").append(tag).append(":");

        // Handle multi-line values
        String[] lines = value.split("\n");
        for (int i = 0; i < lines.length; i++) {
            if (i > 0) sb.append("
");
            sb.append(lines[i]);
        }
        sb.append("
");
    }

    private String buildPartyTagValue(Party party) {
        StringBuilder sb = new StringBuilder();

        if (party.getAccountNumber() != null && !party.getAccountNumber().isEmpty()) {
            sb.append("/").append(party.getAccountNumber());
        }

        if (party.getBic() != null && !party.getBic().isEmpty()) {
            if (sb.length() > 0) sb.append("
");
            sb.append(party.getBic());
        } else if (party.getName() != null && !party.getName().isEmpty()) {
            if (sb.length() > 0) sb.append("
");
            sb.append(party.getName());
            if (party.getAddress() != null) {
                sb.append("
").append(party.getAddress());
            }
            if (party.getCity() != null) {
                sb.append("
").append(party.getCity());
            }
            if (party.getCountry() != null) {
                sb.append("
").append(party.getCountry());
            }
        }

        return sb.toString();
    }

    private String formatMtAmount(BigDecimal amount) {
        // MT format uses comma as decimal separator, no thousands separator
        String formatted = amount.toPlainString();
        return formatted.replace(".", ",");
    }

    @Override
    public String getFormat() {
        return "MT";
    }
}
