package com.swift.translator.api.controller;

import com.swift.translator.application.service.AuditService;
import com.swift.translator.application.service.MessageRoutingService;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;
import java.util.Set;

/**
 * Admin controller for operational management.
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/admin")
@RequiredArgsConstructor
public class AdminController {

    private final MessageRoutingService routingService;
    private final AuditService auditService;

    @GetMapping("/routes")
    public ResponseEntity<Map<String, String>> getRoutes() {
        Set<String> sourceTypes = routingService.getSupportedSourceTypes();
        Map<String, String> routes = new java.util.HashMap<>();
        for (String sourceType : sourceTypes) {
            var targetType = routingService.getDefaultTargetType(
                com.swift.translator.domain.model.message.MessageType.of(sourceType));
            if (targetType != null) {
                routes.put(sourceType, targetType.getTypeCode());
            }
        }
        return ResponseEntity.ok(routes);
    }

    @GetMapping("/audit/{correlationId}")
    public ResponseEntity<AuditService.AuditRecord> getAuditRecord(
            @PathVariable String correlationId) {
        AuditService.AuditRecord record = auditService.getAuditRecord(correlationId);
        if (record == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(record);
    }

    @GetMapping("/stats")
    public ResponseEntity<SystemStats> getStats() {
        return ResponseEntity.ok(SystemStats.builder()
            .timestamp(Instant.now().toString())
            .supportedTypes(routingService.getSupportedSourceTypes().size())
            .build());
    }

    @Data
    @Builder
    public static class SystemStats {
        private String timestamp;
        private int supportedTypes;
        private long totalTranslations;
        private long totalErrors;
        private double averageProcessingTimeMs;
    }
}
