package com.swift.translator.domain.model.canonical;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Singular;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Canonical message representation - the universal intermediate model.
 * 
 * <p>All message formats (MT, MX, JSON, XML) are parsed into this canonical form
 * before transformation. This decouples source parsers from target serializers.</p>
 * 
 * <p>Thread-safe immutable value object.</p>
 */
@Getter
@Builder(toBuilder = true)
@EqualsAndHashCode
@ToString(exclude = "rawPayload")
public final class CanonicalMessage {

    private final MessageHeader header;
    private final Transaction transaction;
    private final List<Party> parties;
    private final List<Amount> amounts;
    private final List<Reference> references;
    private final List<Charge> charges;
    private final List<Narrative> narratives;
    private final ControlBlock control;

    @Singular
    private final Map<String, Object> extensions;

    /** Raw source message for audit/debugging (may be null for memory optimization) */
    private final String rawPayload;

    /**
     * Gets a party by role.
     */
    public Optional<Party> getPartyByRole(PartyRole role) {
        if (parties == null) return Optional.empty();
        return parties.stream()
            .filter(p -> p.getRole() == role)
            .findFirst();
    }

    /**
     * Gets the instructed amount.
     */
    public Optional<Amount> getInstructedAmount() {
        if (amounts == null) return Optional.empty();
        return amounts.stream()
            .filter(a -> a.getType() == AmountType.INSTRUCTED)
            .findFirst();
    }

    /**
     * Gets a reference by type.
     */
    public Optional<Reference> getReferenceByType(String type) {
        if (references == null) return Optional.empty();
        return references.stream()
            .filter(r -> r.getType().equals(type))
            .findFirst();
    }

    /**
     * Returns an unmodifiable view of parties.
     */
    public List<Party> getParties() {
        return parties == null ? Collections.emptyList() : Collections.unmodifiableList(parties);
    }

    /**
     * Returns an unmodifiable view of amounts.
     */
    public List<Amount> getAmounts() {
        return amounts == null ? Collections.emptyList() : Collections.unmodifiableList(amounts);
    }

    /**
     * Creates a builder pre-populated with this message's data.
     */
    public CanonicalMessageBuilder toBuilder() {
        return new CanonicalMessageBuilder()
            .header(this.header)
            .transaction(this.transaction)
            .parties(this.parties)
            .amounts(this.amounts)
            .references(this.references)
            .charges(this.charges)
            .narratives(this.narratives)
            .control(this.control)
            .extensions(this.extensions)
            .rawPayload(this.rawPayload);
    }
}
