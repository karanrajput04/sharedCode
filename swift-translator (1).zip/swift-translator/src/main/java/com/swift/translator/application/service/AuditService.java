package com.swift.translator.application.service;

import com.swift.translator.application.event.TranslationCompletedEvent;
import com.swift.translator.application.event.TranslationFailedEvent;
import com.swift.translator.application.port.inbound.TranslateMessageUseCase;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Service for auditing translation operations.
 * 
 * <p>Records translation attempts, successes, and failures for compliance
 * and operational monitoring.</p>
 */
@Slf4j
@Service
public class AuditService {

    private final ConcurrentHashMap<String, AuditRecord> auditLog;

    public AuditService() {
        this.auditLog = new ConcurrentHashMap<>();
    }

    @Async
    @EventListener
    public void onTranslationCompleted(TranslationCompletedEvent event) {
        log.info("Audit: Translation completed, correlationId={}, processingTimeMs={}, outputSize={}",
            event.getCorrelationId(), event.getProcessingTimeMs(), event.getOutputSize());

        auditLog.put(event.getCorrelationId(), AuditRecord.builder()
            .correlationId(event.getCorrelationId())
            .status("COMPLETED")
            .sourceType(event.getSourceType() != null ? event.getSourceType().getTypeCode() : null)
            .targetType(event.getTargetType() != null ? event.getTargetType().getTypeCode() : null)
            .processingTimeMs(event.getProcessingTimeMs())
            .completedAt(event.getCompletedAt())
            .outputHash(event.getOutputHash())
            .build());
    }

    @Async
    @EventListener
    public void onTranslationFailed(TranslationFailedEvent event) {
        log.error("Audit: Translation failed, correlationId={}, errorCode={}, stage={}, retryable={}",
            event.getCorrelationId(), event.getErrorCode(), event.getStage(), event.isRetryable());

        auditLog.put(event.getCorrelationId(), AuditRecord.builder()
            .correlationId(event.getCorrelationId())
            .status("FAILED")
            .sourceType(event.getSourceType() != null ? event.getSourceType().getTypeCode() : null)
            .targetType(event.getTargetType() != null ? event.getTargetType().getTypeCode() : null)
            .errorCode(event.getErrorCode())
            .errorMessage(event.getErrorMessage())
            .stage(event.getStage())
            .retryable(event.isRetryable())
            .failedAt(event.getFailedAt())
            .build());
    }

    /**
     * Gets an audit record by correlation ID.
     */
    public AuditRecord getAuditRecord(String correlationId) {
        return auditLog.get(correlationId);
    }

    /**
     * Audit record for translation operations.
     */
    public record AuditRecord(
        String correlationId,
        String status,
        String sourceType,
        String targetType,
        Long processingTimeMs,
        String errorCode,
        String errorMessage,
        String stage,
        Boolean retryable,
        Instant completedAt,
        Instant failedAt,
        String outputHash
    ) {
        public static AuditRecordBuilder builder() {
            return new AuditRecordBuilder();
        }

        public static class AuditRecordBuilder {
            private String correlationId;
            private String status;
            private String sourceType;
            private String targetType;
            private Long processingTimeMs;
            private String errorCode;
            private String errorMessage;
            private String stage;
            private Boolean retryable;
            private Instant completedAt;
            private Instant failedAt;
            private String outputHash;

            public AuditRecordBuilder correlationId(String correlationId) {
                this.correlationId = correlationId; return this;
            }
            public AuditRecordBuilder status(String status) {
                this.status = status; return this;
            }
            public AuditRecordBuilder sourceType(String sourceType) {
                this.sourceType = sourceType; return this;
            }
            public AuditRecordBuilder targetType(String targetType) {
                this.targetType = targetType; return this;
            }
            public AuditRecordBuilder processingTimeMs(Long processingTimeMs) {
                this.processingTimeMs = processingTimeMs; return this;
            }
            public AuditRecordBuilder errorCode(String errorCode) {
                this.errorCode = errorCode; return this;
            }
            public AuditRecordBuilder errorMessage(String errorMessage) {
                this.errorMessage = errorMessage; return this;
            }
            public AuditRecordBuilder stage(String stage) {
                this.stage = stage; return this;
            }
            public AuditRecordBuilder retryable(Boolean retryable) {
                this.retryable = retryable; return this;
            }
            public AuditRecordBuilder completedAt(Instant completedAt) {
                this.completedAt = completedAt; return this;
            }
            public AuditRecordBuilder failedAt(Instant failedAt) {
                this.failedAt = failedAt; return this;
            }
            public AuditRecordBuilder outputHash(String outputHash) {
                this.outputHash = outputHash; return this;
            }

            public AuditRecord build() {
                return new AuditRecord(correlationId, status, sourceType, targetType,
                    processingTimeMs, errorCode, errorMessage, stage, retryable,
                    completedAt, failedAt, outputHash);
            }
        }
    }
}
