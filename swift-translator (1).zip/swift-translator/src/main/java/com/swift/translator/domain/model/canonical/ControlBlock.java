package com.swift.translator.domain.model.canonical;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * Control and trailer information from SWIFT messages.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class ControlBlock {

    private final String mac;
    private final String chk;
    private final String pdm;
    private final String mir;
    private final String mur;
    private final String duplicateIndicator;
    private final String possibleDuplicate;
    private final String messageUserReference;
    private final String serviceTypeIdentifier;
}
