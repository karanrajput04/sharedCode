package com.swift.translator.infrastructure.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * Metrics collector for translation operations.
 */
@Component
@RequiredArgsConstructor
public class TranslationMetrics {

    private final MeterRegistry meterRegistry;

    public void recordTranslation(String sourceType, String targetType, long durationMs, boolean success) {
        String status = success ? "success" : "error";

        Timer.builder("translation.duration")
            .tag("source", sourceType)
            .tag("target", targetType)
            .tag("status", status)
            .register(meterRegistry)
            .record(durationMs, TimeUnit.MILLISECONDS);

        Counter.builder("translation.count")
            .tag("source", sourceType)
            .tag("target", targetType)
            .tag("status", status)
            .register(meterRegistry)
            .increment();
    }

    public void recordParsing(String format, long durationMs, boolean success) {
        Timer.builder("parsing.duration")
            .tag("format", format)
            .tag("status", success ? "success" : "error")
            .register(meterRegistry)
            .record(durationMs, TimeUnit.MILLISECONDS);
    }

    public void recordSerialization(String format, long durationMs, boolean success) {
        Timer.builder("serialization.duration")
            .tag("format", format)
            .tag("status", success ? "success" : "error")
            .register(meterRegistry)
            .record(durationMs, TimeUnit.MILLISECONDS);
    }
}
