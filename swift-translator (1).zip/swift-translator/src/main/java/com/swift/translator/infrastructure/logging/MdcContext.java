package com.swift.translator.infrastructure.logging;

import org.slf4j.MDC;

import java.util.Map;
import java.util.UUID;

/**
 * Utility for managing MDC (Mapped Diagnostic Context) values.
 */
public class MdcContext {

    public static final String CORRELATION_ID = "correlationId";
    public static final String TRANSACTION_ID = "transactionId";
    public static final String MESSAGE_ID = "messageId";
    public static final String STAGE = "stage";
    public static final String DIRECTION = "direction";

    private MdcContext() {
        // Utility class
    }

    public static void setCorrelationId(String correlationId) {
        MDC.put(CORRELATION_ID, correlationId);
    }

    public static void setTransactionId(String transactionId) {
        MDC.put(TRANSACTION_ID, transactionId);
    }

    public static void setMessageId(String messageId) {
        MDC.put(MESSAGE_ID, messageId);
    }

    public static void setStage(String stage) {
        MDC.put(STAGE, stage);
    }

    public static void setDirection(String direction) {
        MDC.put(DIRECTION, direction);
    }

    public static void clear() {
        MDC.clear();
    }

    public static Map<String, String> getContext() {
        return MDC.getCopyOfContextMap();
    }

    public static void setContext(Map<String, String> context) {
        if (context != null) {
            MDC.setContextMap(context);
        }
    }
}
