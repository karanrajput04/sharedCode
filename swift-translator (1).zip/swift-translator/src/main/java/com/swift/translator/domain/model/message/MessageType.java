package com.swift.translator.domain.model.message;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.Objects;
import java.util.regex.Pattern;

/**
 * Immutable value object representing a specific message type.
 * 
 * <p>Examples: MT103, pacs.008.001.08, pain.001.001.09</p>
 * 
 * <p>Thread-safe and immutable.</p>
 */
@Getter
@EqualsAndHashCode
@ToString
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class MessageType {

    private static final Pattern MT_PATTERN = Pattern.compile("^MT[0-9]{3}[A-Z]?$");
    private static final Pattern MX_PATTERN = Pattern.compile("^[a-z]{4}\.[0-9]{3}\.[0-9]{3}\.[0-9]{2}$");

    private final String typeCode;
    private final MessageFormat format;
    private final String version;

    /**
     * Creates a MessageType from a string code.
     * 
     * @param typeCode the message type code (e.g., "MT103", "pacs.008.001.08")
     * @return a validated MessageType instance
     * @throws IllegalArgumentException if the type code is invalid
     */
    public static MessageType of(String typeCode) {
        Objects.requireNonNull(typeCode, "typeCode must not be null");
        String normalized = typeCode.trim().toUpperCase();

        if (MT_PATTERN.matcher(normalized).matches()) {
            return new MessageType(normalized, MessageFormat.MT, null);
        }

        String lower = typeCode.trim().toLowerCase();
        if (MX_PATTERN.matcher(lower).matches()) {
            String[] parts = lower.split("\.");
            return new MessageType(lower, MessageFormat.MX, parts[3]);
        }

        throw new IllegalArgumentException(
            "Invalid message type code: " + typeCode + 
            ". Expected MTnnn or xxx.yyy.zzz.vv format");
    }

    /**
     * Creates a MessageType from a MessageFormat and code.
     */
    public static MessageType of(MessageFormat format, String typeCode, String version) {
        Objects.requireNonNull(format, "format must not be null");
        Objects.requireNonNull(typeCode, "typeCode must not be null");
        return new MessageType(typeCode, format, version);
    }

    /**
     * Checks if this is an MT message type.
     */
    public boolean isMt() {
        return format == MessageFormat.MT;
    }

    /**
     * Checks if this is an MX message type.
     */
    public boolean isMx() {
        return format == MessageFormat.MX;
    }
}
