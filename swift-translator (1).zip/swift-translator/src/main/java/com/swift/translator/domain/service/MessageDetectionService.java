package com.swift.translator.domain.service;

import com.swift.translator.domain.model.message.MessageFormat;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ParsingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Service for detecting message format and type from raw message content.
 * 
 * <p>Supports auto-detection of MT, MX, JSON, and CSV formats.</p>
 */
@Slf4j
@Service
public class MessageDetectionService {

    private static final Pattern MT_BLOCK1_PATTERN = Pattern.compile(
        "\{1:(F|L)?(01|21)([A-Z]{12})([0-9]{4})([0-9]{6})([A-Z0-9]{4})([0-9]{6})([0-9]{4})([A-Z])?\}"
    );

    private static final Pattern MT_MESSAGE_TYPE_PATTERN = Pattern.compile(
        "\{2:(I|O)?([0-9]{3})([A-Z0-9]{4})([A-Z])([0-9])?([0-9])?\}"
    );

    private static final Pattern MX_NAMESPACE_PATTERN = Pattern.compile(
        "xmlns="urn:iso:std:iso:20022:tech:xsd:([a-z]{4})\.([0-9]{3})\.([0-9]{3})\.([0-9]{2})""
    );

    private static final Pattern MX_ROOT_PATTERN = Pattern.compile(
        "<([A-Za-z0-9]+:)?Document[^>]*>"
    );

    /**
     * Detects message format and type from raw content.
     * 
     * @param content the raw message content
     * @return detected message type
     * @throws ParsingException if format cannot be determined
     */
    public MessageType detect(String content) {
        if (content == null || content.trim().isEmpty()) {
            throw new ParsingException("Message content is empty", "DETECT_EMPTY", null);
        }

        String trimmed = content.trim();

        // Check for MT format (starts with {1:)
        if (trimmed.startsWith("{1:")) {
            return detectMtType(trimmed);
        }

        // Check for XML/MX format
        if (trimmed.startsWith("<?xml") || trimmed.startsWith("<")) {
            return detectXmlType(trimmed);
        }

        // Check for JSON format
        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            return detectJsonType(trimmed);
        }

        // Check for CSV format
        if (trimmed.contains(",") && trimmed.contains("\n")) {
            return MessageType.of(MessageFormat.CSV, "UNKNOWN", null);
        }

        throw new ParsingException(
            "Unable to detect message format from content: " + trimmed.substring(0, Math.min(100, trimmed.length())),
            "DETECT_UNKNOWN", null);
    }

    private MessageType detectMtType(String content) {
        Matcher matcher = MT_MESSAGE_TYPE_PATTERN.matcher(content);
        if (matcher.find()) {
            String typeCode = "MT" + matcher.group(2);
            log.debug("Detected MT message type: {}", typeCode);
            return MessageType.of(typeCode);
        }

        // Fallback: try to extract from block 1
        Matcher block1Matcher = MT_BLOCK1_PATTERN.matcher(content);
        if (block1Matcher.find()) {
            log.debug("Detected MT message from block 1, but no block 2 found");
        }

        throw new ParsingException("MT message detected but type cannot be determined", "DETECT_MT_FAIL", null);
    }

    private MessageType detectXmlType(String content) {
        // Check for ISO 20022 MX message
        Matcher nsMatcher = MX_NAMESPACE_PATTERN.matcher(content);
        if (nsMatcher.find()) {
            String typeCode = String.format("%s.%s.%s.%s",
                nsMatcher.group(1), nsMatcher.group(2), 
                nsMatcher.group(3), nsMatcher.group(4));
            log.debug("Detected MX message type: {}", typeCode);
            return MessageType.of(typeCode);
        }

        // Generic XML
        Matcher rootMatcher = MX_ROOT_PATTERN.matcher(content);
        if (rootMatcher.find()) {
            log.debug("Detected generic XML message");
            return MessageType.of(MessageFormat.XML, "GENERIC", null);
        }

        throw new ParsingException("XML detected but namespace not recognized", "DETECT_XML_FAIL", null);
    }

    private MessageType detectJsonType(String content) {
        log.debug("Detected JSON message");
        return MessageType.of(MessageFormat.JSON, "GENERIC", null);
    }

    /**
     * Determines if content is MT format.
     */
    public boolean isMtFormat(String content) {
        return content != null && content.trim().startsWith("{1:");
    }

    /**
     * Determines if content is MX format.
     */
    public boolean isMxFormat(String content) {
        if (content == null) return false;
        String trimmed = content.trim();
        return trimmed.startsWith("<?xml") || 
               (trimmed.startsWith("<") && trimmed.contains("Document"));
    }
}
