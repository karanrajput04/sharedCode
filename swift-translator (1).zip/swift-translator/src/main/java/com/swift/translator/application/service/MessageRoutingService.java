package com.swift.translator.application.service;

import com.swift.translator.domain.model.message.MessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Service for routing messages based on type and business rules.
 * 
 * <p>Determines target format and routing destination based on source message type
 * and configured routing rules.</p>
 */
@Slf4j
@Service
public class MessageRoutingService {

    private final Map<String, String> routingTable;

    public MessageRoutingService() {
        this.routingTable = new ConcurrentHashMap<>();
        initializeDefaultRoutes();
    }

    private void initializeDefaultRoutes() {
        // MT to MX routes
        routingTable.put("MT103", "pacs.008.001.08");
        routingTable.put("MT103_STP", "pacs.008.001.08");
        routingTable.put("MT103_REMIT", "pacs.008.001.08");
        routingTable.put("MT202", "pacs.009.001.08");
        routingTable.put("MT202COV", "pacs.009.001.08");
        routingTable.put("MT205", "pacs.009.001.08");
        routingTable.put("MT205COV", "pacs.009.001.08");
        routingTable.put("MT540", "semt.017.001.01");
        routingTable.put("MT541", "semt.017.001.01");
        routingTable.put("MT542", "semt.017.001.01");
        routingTable.put("MT543", "semt.017.001.01");
        routingTable.put("MT544", "semt.017.001.01");
        routingTable.put("MT545", "semt.017.001.01");
        routingTable.put("MT546", "semt.017.001.01");
        routingTable.put("MT547", "semt.017.001.01");
        routingTable.put("MT548", "semt.017.001.01");
        routingTable.put("MT900", "camt.054.001.08");
        routingTable.put("MT910", "camt.054.001.08");
        routingTable.put("MT950", "camt.053.001.08");
        routingTable.put("MTn92", "pacs.004.001.09");
        routingTable.put("MTn95", "camt.029.001.09");
        routingTable.put("MTn96", "camt.029.001.09");

        // MX to MT routes
        routingTable.put("pacs.008.001.08", "MT103");
        routingTable.put("pacs.009.001.08", "MT202");
        routingTable.put("pacs.004.001.09", "MTn92");
        routingTable.put("pain.001.001.09", "MT104");
        routingTable.put("pain.002.001.10", "MT096");
        routingTable.put("pain.007.001.09", "MTn92");
        routingTable.put("pain.008.001.08", "MT104");
        routingTable.put("camt.052.001.08", "MT941");
        routingTable.put("camt.053.001.08", "MT950");
        routingTable.put("camt.054.001.08", "MT900");
        routingTable.put("camt.029.001.09", "MTn96");
        routingTable.put("camt.056.001.08", "MTn92");
        routingTable.put("camt.087.001.06", "MTn95");
    }

    /**
     * Gets the default target message type for a source type.
     */
    public MessageType getDefaultTargetType(MessageType sourceType) {
        String targetCode = routingTable.get(sourceType.getTypeCode());
        if (targetCode == null) {
            log.warn("No default route found for source type: {}", sourceType.getTypeCode());
            return null;
        }
        return MessageType.of(targetCode);
    }

    /**
     * Checks if a route exists between source and target types.
     */
    public boolean isRouteSupported(MessageType sourceType, MessageType targetType) {
        String expectedTarget = routingTable.get(sourceType.getTypeCode());
        return expectedTarget != null && expectedTarget.equals(targetType.getTypeCode());
    }

    /**
     * Registers a custom route.
     */
    public void registerRoute(String sourceType, String targetType) {
        routingTable.put(sourceType, targetType);
        log.info("Registered route: {} -> {}", sourceType, targetType);
    }

    /**
     * Gets all supported source types.
     */
    public java.util.Set<String> getSupportedSourceTypes() {
        return java.util.Collections.unmodifiableSet(routingTable.keySet());
    }
}
