package com.swift.translator.engine.parser;

import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ParsingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Factory for creating appropriate parser based on message type.
 * 
 * <p>Uses strategy pattern to select parser implementation.</p>
 */
@Slf4j
@Component
public class ParserFactory {

    private final List<MessageParser> parsers;
    private final Map<MessageType, MessageParser> parserCache;

    public ParserFactory(List<MessageParser> parsers) {
        this.parsers = parsers;
        this.parserCache = new ConcurrentHashMap<>();
    }

    /**
     * Gets the appropriate parser for the given message type.
     * 
     * @param messageType the message type to parse
     * @return the matching parser
     * @throws ParsingException if no suitable parser is found
     */
    public MessageParser getParser(MessageType messageType) {
        return parserCache.computeIfAbsent(messageType, type -> {
            for (MessageParser parser : parsers) {
                if (parser.supports(type)) {
                    log.debug("Selected parser {} for message type {}", parser.getClass().getSimpleName(), type);
                    return parser;
                }
            }
            throw new ParsingException("No parser found for message type: " + type, 
                "PARSER_NOT_FOUND", null);
        });
    }

    /**
     * Registers a new parser (for plugin architecture).
     */
    public void registerParser(MessageParser parser) {
        parsers.add(parser);
        parserCache.clear();
        log.info("Registered parser: {}", parser.getClass().getSimpleName());
    }
}
