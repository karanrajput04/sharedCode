package com.swift.translator.domain.exception;

import com.swift.translator.domain.model.message.MessageMetadata;

/**
 * Exception thrown when message parsing fails.
 */
public class ParsingException extends TranslationException {

    public ParsingException(String message, String errorCode, MessageMetadata metadata) {
        super(message, errorCode, metadata);
    }

    public ParsingException(String message, Throwable cause, String errorCode, MessageMetadata metadata) {
        super(message, cause, errorCode, metadata);
    }
}
