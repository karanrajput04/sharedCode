package com.swift.translator.engine.serializer;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;

/**
 * Strategy interface for serializing canonical messages to target format.
 */
public interface MessageSerializer {

    /**
     * Checks if this serializer supports the given message type.
     */
    boolean supports(MessageType messageType);

    /**
     * Serializes canonical message to target format.
     * 
     * @param canonicalMessage the canonical message to serialize
     * @param targetType the desired target message type
     * @param metadata message metadata for error context
     * @return serialized message content
     */
    String serialize(CanonicalMessage canonicalMessage, MessageType targetType, MessageMetadata metadata);

    /**
     * Returns the format this serializer produces.
     */
    String getFormat();
}
