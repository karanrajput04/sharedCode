package com.swift.translator.engine.validator;

import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.exception.ValidationException;
import com.swift.translator.engine.validator.ValidationEngine.Validator;
import com.swift.translator.engine.validator.ValidationEngine.ValidationContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Business rule validator for common SWIFT/ISO 20022 business rules.
 */
@Slf4j
@Component
public class BusinessRuleValidator implements Validator {

    private static final Pattern BIC_PATTERN = Pattern.compile("^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$");
    private static final Pattern CURRENCY_PATTERN = Pattern.compile("^[A-Z]{3}$");
    private static final Pattern IBAN_PATTERN = Pattern.compile("^[A-Z]{2}[0-9]{2}[A-Z0-9]{1,30}$");

    // Maximum amount limits by currency (example values)
    private static final BigDecimal MAX_AMOUNT_DEFAULT = new BigDecimal("999999999999.99");

    @Override
    public String getName() {
        return "BusinessRuleValidator";
    }

    @Override
    public boolean supports(MessageType messageType, ValidationContext context) {
        return context == ValidationContext.BUSINESS || context == ValidationContext.OUTPUT;
    }

    @Override
    public List<ValidationException.ValidationError> validate(CanonicalMessage message, 
                                                               MessageType messageType, 
                                                               MessageMetadata metadata) {
        List<ValidationException.ValidationError> errors = new ArrayList<>();

        // Validate amounts
        validateAmounts(message, errors);

        // Validate parties
        validateParties(message, errors);

        // Validate references
        validateReferences(message, errors);

        // Validate transaction details
        validateTransaction(message, errors);

        return errors;
    }

    private void validateAmounts(CanonicalMessage message, List<ValidationException.ValidationError> errors) {
        if (message.getAmounts() == null || message.getAmounts().isEmpty()) {
            errors.add(new ValidationException.ValidationError(
                "amounts", "AMOUNT_MISSING", "At least one amount is required", "ERROR"));
            return;
        }

        for (var amount : message.getAmounts()) {
            // Validate currency
            if (amount.getCurrency() == null || !CURRENCY_PATTERN.matcher(amount.getCurrency()).matches()) {
                errors.add(new ValidationException.ValidationError(
                    "amount.currency", "INVALID_CURRENCY", 
                    "Invalid currency code: " + amount.getCurrency(), "ERROR"));
            }

            // Validate amount value
            if (amount.getValue() == null || amount.getValue().compareTo(BigDecimal.ZERO) <= 0) {
                errors.add(new ValidationException.ValidationError(
                    "amount.value", "INVALID_AMOUNT", 
                    "Amount must be positive: " + amount.getValue(), "ERROR"));
            }

            // Validate amount not too large
            if (amount.getValue() != null && amount.getValue().compareTo(MAX_AMOUNT_DEFAULT) > 0) {
                errors.add(new ValidationException.ValidationError(
                    "amount.value", "AMOUNT_TOO_LARGE", 
                    "Amount exceeds maximum allowed: " + amount.getValue(), "ERROR"));
            }

            // Validate decimal places
            if (amount.getValue() != null && amount.getDecimalPlaces() != null) {
                int actualDecimals = amount.getValue().scale();
                if (actualDecimals > amount.getDecimalPlaces()) {
                    errors.add(new ValidationException.ValidationError(
                        "amount.decimals", "TOO_MANY_DECIMALS", 
                        "Amount has too many decimal places: " + actualDecimals, "WARNING"));
                }
            }
        }
    }

    private void validateParties(CanonicalMessage message, List<ValidationException.ValidationError> errors) {
        if (message.getParties() == null || message.getParties().isEmpty()) {
            errors.add(new ValidationException.ValidationError(
                "parties", "PARTIES_MISSING", "At least one party is required", "ERROR"));
            return;
        }

        for (var party : message.getParties()) {
            // Validate BIC if present
            if (party.getBic() != null && !party.getBic().isEmpty()) {
                if (!BIC_PATTERN.matcher(party.getBic()).matches()) {
                    errors.add(new ValidationException.ValidationError(
                        "party.bic", "INVALID_BIC", 
                        "Invalid BIC format: " + party.getBic(), "ERROR"));
                }
            }

            // Validate BICFI if present
            if (party.getBicfi() != null && !party.getBicfi().isEmpty()) {
                if (!BIC_PATTERN.matcher(party.getBicfi()).matches()) {
                    errors.add(new ValidationException.ValidationError(
                        "party.bicfi", "INVALID_BICFI", 
                        "Invalid BICFI format: " + party.getBicfi(), "ERROR"));
                }
            }

            // Validate IBAN if present
            if (party.getAccountNumber() != null && party.getAccountNumber().startsWith("IBAN")) {
                String iban = party.getAccountNumber().replace("IBAN", "").trim();
                if (!IBAN_PATTERN.matcher(iban).matches()) {
                    errors.add(new ValidationException.ValidationError(
                        "party.account", "INVALID_IBAN", 
                        "Invalid IBAN format: " + iban, "ERROR"));
                }
            }

            // Validate required fields based on role
            if (party.getRole() == com.swift.translator.domain.model.canonical.PartyRole.DEBTOR ||
                party.getRole() == com.swift.translator.domain.model.canonical.PartyRole.CREDITOR) {
                if (party.getName() == null || party.getName().isEmpty()) {
                    errors.add(new ValidationException.ValidationError(
                        "party.name", "NAME_REQUIRED", 
                        "Party name is required for role: " + party.getRole(), "ERROR"));
                }
            }
        }
    }

    private void validateReferences(CanonicalMessage message, List<ValidationException.ValidationError> errors) {
        if (message.getReferences() == null || message.getReferences().isEmpty()) {
            errors.add(new ValidationException.ValidationError(
                "references", "REFERENCE_MISSING", 
                "At least one reference is recommended", "WARNING"));
            return;
        }

        for (var reference : message.getReferences()) {
            if (reference.getValue() == null || reference.getValue().isEmpty()) {
                errors.add(new ValidationException.ValidationError(
                    "reference.value", "EMPTY_REFERENCE", 
                    "Reference value cannot be empty", "ERROR"));
            }

            if (reference.getValue() != null && reference.getValue().length() > 35) {
                errors.add(new ValidationException.ValidationError(
                    "reference.value", "REFERENCE_TOO_LONG", 
                    "Reference value exceeds 35 characters", "WARNING"));
            }
        }
    }

    private void validateTransaction(CanonicalMessage message, List<ValidationException.ValidationError> errors) {
        if (message.getTransaction() == null) {
            errors.add(new ValidationException.ValidationError(
                "transaction", "TRANSACTION_MISSING", "Transaction details are required", "ERROR"));
            return;
        }

        var transaction = message.getTransaction();

        // Validate transaction reference
        if (transaction.getTransactionReference() == null || transaction.getTransactionReference().isEmpty()) {
            errors.add(new ValidationException.ValidationError(
                "transaction.reference", "REFERENCE_MISSING", 
                "Transaction reference is required", "ERROR"));
        }

        // Validate value date
        if (transaction.getValueDate() == null) {
            errors.add(new ValidationException.ValidationError(
                "transaction.valueDate", "VALUE_DATE_MISSING", 
                "Value date is required", "ERROR"));
        }

        // Validate charge bearer
        if (transaction.getChargeBearer() != null) {
            String cb = transaction.getChargeBearer();
            if (!List.of("BEN", "SHA", "OUR", "CRED", "SHAR", "DEBT", "SLEV").contains(cb)) {
                errors.add(new ValidationException.ValidationError(
                    "transaction.chargeBearer", "INVALID_CHARGE_BEARER", 
                    "Invalid charge bearer: " + cb, "ERROR"));
            }
        }
    }
}
