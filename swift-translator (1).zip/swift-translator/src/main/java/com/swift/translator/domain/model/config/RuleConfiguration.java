package com.swift.translator.domain.model.config;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Singular;
import lombok.ToString;

import java.util.Collections;
import java.util.List;

/**
 * Configuration for business rules.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class RuleConfiguration {

    @Singular
    private final List<Rule> rules;

    public List<Rule> getRules() {
        return rules == null ? Collections.emptyList() : Collections.unmodifiableList(rules);
    }

    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class Rule {
        private final String id;
        private final String name;
        private final int priority;
        private final Condition condition;
        private final String action; // ALLOW, BLOCK, FLAG, REJECT
        private final String message;
        private final boolean stopOnMatch;
    }

    @Getter
    @Builder
    @EqualsAndHashCode
    @ToString
    public static class Condition {
        private final String type; // AND, OR, NOT, FIELD
        @Singular
        private final List<Condition> conditions;
        private final String field;
        private final String operator; // EQUALS, NOT_EQUALS, GREATER_THAN, LESS_THAN, CONTAINS, MATCHES, IN
        private final Object value;
    }
}
