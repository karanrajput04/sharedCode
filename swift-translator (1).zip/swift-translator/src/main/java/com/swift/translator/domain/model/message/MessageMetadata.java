package com.swift.translator.domain.model.message;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.time.Instant;
import java.util.UUID;

/**
 * Immutable metadata associated with a message throughout its lifecycle.
 * 
 * <p>Carries correlation and tracking information across all pipeline stages.</p>
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class MessageMetadata {

    @Builder.Default
    private final String correlationId = UUID.randomUUID().toString();

    @Builder.Default
    private final String transactionId = UUID.randomUUID().toString();

    private final String messageId;
    private final String senderBic;
    private final String receiverBic;
    private final MessageType sourceType;
    private final MessageType targetType;
    private final MessageDirection direction;

    @Builder.Default
    private final Instant receivedAt = Instant.now();

    private Instant processedAt;
    private String processingStage;
    private String processingNode;

    /**
     * Marks the message as processed with current timestamp.
     */
    public MessageMetadata markProcessed() {
        return this.toBuilder()
            .processedAt(Instant.now())
            .build();
    }

    /**
     * Updates the current processing stage.
     */
    public MessageMetadata withStage(String stage) {
        return this.toBuilder()
            .processingStage(stage)
            .build();
    }
}
