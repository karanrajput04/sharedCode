package com.swift.translator.api.dto;

import lombok.Builder;
import lombok.Data;

/**
 * DTO for message detection responses.
 */
@Data
@Builder
public class DetectionResponse {

    private String correlationId;
    private String detectedType;
    private String detectedFormat;
    private double confidence;
    private String timestamp;
}
