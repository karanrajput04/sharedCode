package com.swift.translator.domain.exception;

import com.swift.translator.domain.model.message.MessageMetadata;
import lombok.Getter;

/**
 * Base exception for all translation errors.
 * 
 * <p>Carries correlation ID and processing stage for debugging.</p>
 */
@Getter
public class TranslationException extends RuntimeException {

    private final String correlationId;
    private final String stage;
    private final String errorCode;

    public TranslationException(String message, String errorCode, MessageMetadata metadata) {
        super(message);
        this.errorCode = errorCode;
        this.correlationId = metadata != null ? metadata.getCorrelationId() : null;
        this.stage = metadata != null ? metadata.getProcessingStage() : null;
    }

    public TranslationException(String message, Throwable cause, String errorCode, MessageMetadata metadata) {
        super(message, cause);
        this.errorCode = errorCode;
        this.correlationId = metadata != null ? metadata.getCorrelationId() : null;
        this.stage = metadata != null ? metadata.getProcessingStage() : null;
    }

    @Override
    public String getMessage() {
        return String.format("[%s|%s] %s (correlationId=%s)", 
            errorCode, stage, super.getMessage(), correlationId);
    }
}
