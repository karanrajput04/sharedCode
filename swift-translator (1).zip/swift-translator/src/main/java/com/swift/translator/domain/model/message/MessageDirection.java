package com.swift.translator.domain.model.message;

/**
 * Direction of message flow through the translation pipeline.
 */
public enum MessageDirection {
    /** Message being translated from source to target */
    INBOUND,

    /** Translated message being dispatched */
    OUTBOUND,

    /** Bidirectional translation */
    BIDIRECTIONAL
}
