package com.swift.translator.domain.model.canonical;

import com.swift.translator.domain.model.message.MessageType;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.time.LocalDateTime;

/**
 * Message header containing routing and identification information.
 */
@Getter
@Builder
@EqualsAndHashCode
@ToString
public final class MessageHeader {

    private final String messageId;
    private final MessageType messageType;
    private final String senderBic;
    private final String receiverBic;
    private final LocalDateTime creationDateTime;
    private final String priority;
    private final String deliveryMonitoring;
    private final String obsolescencePeriod;
    private final String networkReference;
    private final String userReference;
    private final String serviceId;
    private final String applicationId;
    private final String sessionNumber;
    private final String sequenceNumber;
}
