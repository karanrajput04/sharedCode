package com.swift.translator.application.service;

import com.swift.translator.application.event.TranslationCompletedEvent;
import com.swift.translator.application.event.TranslationFailedEvent;
import com.swift.translator.application.port.inbound.TranslateMessageUseCase;
import com.swift.translator.domain.model.canonical.CanonicalMessage;
import com.swift.translator.domain.model.message.MessageFormat;
import com.swift.translator.domain.model.message.MessageMetadata;
import com.swift.translator.domain.model.message.MessageType;
import com.swift.translator.domain.service.MessageDetectionService;
import com.swift.translator.engine.parser.ParserFactory;
import com.swift.translator.engine.serializer.SerializerFactory;
import com.swift.translator.engine.mapper.MappingEngine;
import com.swift.translator.engine.rule.RuleEngine;
import com.swift.translator.engine.validator.ValidationEngine;
import com.swift.translator.infrastructure.metrics.PerformanceTimer;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.concurrent.TimeUnit;

/**
 * Core translation service implementing the translation use case.
 * 
 * <p>Orchestrates the complete translation pipeline:
 * Detection -> Parsing -> Validation(Input) -> Mapping -> Transformation -> 
 * Rule Engine -> Validation(Output) -> Serialization -> Audit</p>
 */
@Slf4j
@Service
@Transactional
public class TranslationService implements TranslateMessageUseCase {

    private final MessageDetectionService detectionService;
    private final ParserFactory parserFactory;
    private final SerializerFactory serializerFactory;
    private final MappingEngine mappingEngine;
    private final RuleEngine ruleEngine;
    private final ValidationEngine validationEngine;
    private final ApplicationEventPublisher eventPublisher;
    private final MeterRegistry meterRegistry;
    private final PerformanceTimer performanceTimer;

    public TranslationService(MessageDetectionService detectionService,
                              ParserFactory parserFactory,
                              SerializerFactory serializerFactory,
                              MappingEngine mappingEngine,
                              RuleEngine ruleEngine,
                              ValidationEngine validationEngine,
                              ApplicationEventPublisher eventPublisher,
                              MeterRegistry meterRegistry,
                              PerformanceTimer performanceTimer) {
        this.detectionService = detectionService;
        this.parserFactory = parserFactory;
        this.serializerFactory = serializerFactory;
        this.mappingEngine = mappingEngine;
        this.ruleEngine = ruleEngine;
        this.validationEngine = validationEngine;
        this.eventPublisher = eventPublisher;
        this.meterRegistry = meterRegistry;
        this.performanceTimer = performanceTimer;
    }

    @Override
    public TranslationResult translate(String rawMessage, MessageType sourceType,
                                      MessageType targetType, MessageMetadata metadata) {
        long startTime = System.currentTimeMillis();
        MessageMetadata currentMetadata = metadata.withStage("TRANSLATION_STARTED");

        Timer.Sample sample = Timer.start(meterRegistry);

        try {
            log.info("Starting translation: {} -> {}, correlationId: {}", 
                sourceType.getTypeCode(), targetType.getTypeCode(), metadata.getCorrelationId());

            // Stage 1: Parse source message to canonical form
            currentMetadata = currentMetadata.withStage("PARSING");
            CanonicalMessage canonicalMessage = parserFactory
                .getParser(sourceType)
                .parse(rawMessage, sourceType, currentMetadata);

            recordStageTiming("parsing", startTime, metadata);

            // Stage 2: Validate input
            currentMetadata = currentMetadata.withStage("VALIDATION_INPUT");
            validationEngine.validate(canonicalMessage, sourceType, currentMetadata, 
                ValidationEngine.ValidationContext.INPUT);

            recordStageTiming("validation_input", startTime, metadata);

            // Stage 3: Apply business rules
            currentMetadata = currentMetadata.withStage("RULE_EVALUATION");
            // Rule evaluation would load config and apply - simplified here

            recordStageTiming("rule_evaluation", startTime, metadata);

            // Stage 4: Apply mapping configuration
            currentMetadata = currentMetadata.withStage("MAPPING");
            // Mapping would load config and apply - simplified here
            // canonicalMessage = mappingEngine.applyMapping(canonicalMessage, mappingConfig, currentMetadata);

            recordStageTiming("mapping", startTime, metadata);

            // Stage 5: Validate output
            currentMetadata = currentMetadata.withStage("VALIDATION_OUTPUT");
            validationEngine.validate(canonicalMessage, targetType, currentMetadata,
                ValidationEngine.ValidationContext.OUTPUT);

            recordStageTiming("validation_output", startTime, metadata);

            // Stage 6: Serialize canonical message to target format
            currentMetadata = currentMetadata.withStage("SERIALIZATION");
            String output = serializerFactory
                .getSerializer(targetType)
                .serialize(canonicalMessage, targetType, currentMetadata);

            recordStageTiming("serialization", startTime, metadata);

            long processingTime = System.currentTimeMillis() - startTime;

            // Record metrics
            sample.stop(meterRegistry.timer("translation.duration", 
                "source", sourceType.getTypeCode(),
                "target", targetType.getTypeCode(),
                "status", "success"));

            meterRegistry.counter("translation.total", 
                "source", sourceType.getTypeCode(),
                "target", targetType.getTypeCode(),
                "status", "success").increment();

            // Publish success event
            TranslationResult result = new TranslationResult(
                output, sourceType, targetType, 
                currentMetadata.markProcessed(), true, null, processingTime);

            eventPublisher.publishEvent(TranslationCompletedEvent.from(result));

            log.info("Translation completed in {}ms, correlationId: {}", 
                processingTime, metadata.getCorrelationId());

            return result;

        } catch (Exception e) {
            long processingTime = System.currentTimeMillis() - startTime;

            sample.stop(meterRegistry.timer("translation.duration",
                "source", sourceType.getTypeCode(),
                "target", targetType.getTypeCode(),
                "status", "error"));

            meterRegistry.counter("translation.total",
                "source", sourceType.getTypeCode(),
                "target", targetType.getTypeCode(),
                "status", "error").increment();

            log.error("Translation failed after {}ms, correlationId: {}, stage: {}, error: {}", 
                processingTime, metadata.getCorrelationId(), 
                currentMetadata.getProcessingStage(), e.getMessage(), e);

            eventPublisher.publishEvent(TranslationFailedEvent.from(
                metadata.getCorrelationId(), e, sourceType, targetType,
                currentMetadata.getProcessingStage(), isRetryable(e)));

            throw e;
        }
    }

    @Override
    public TranslationResult translate(String rawMessage, MessageType targetType, 
                                      MessageMetadata metadata) {
        MessageType sourceType = detectionService.detect(rawMessage);
        return translate(rawMessage, sourceType, targetType, metadata);
    }

    private boolean isRetryable(Exception e) {
        return !(e instanceof com.swift.translator.domain.exception.ValidationException)
            && !(e instanceof com.swift.translator.domain.exception.ParsingException);
    }

    private void recordStageTiming(String stage, long startTime, MessageMetadata metadata) {
        long elapsed = System.currentTimeMillis() - startTime;
        log.debug("Stage {} completed in {}ms, correlationId: {}", stage, elapsed, metadata.getCorrelationId());
    }
}
