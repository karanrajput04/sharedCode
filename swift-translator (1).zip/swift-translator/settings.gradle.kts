rootProject.name = "swift-translator"
