# Swift Translator - API Reference

## Endpoints

### POST /api/v1/translate
Translates a message from source format to target format.

**Request Headers:**
- `Content-Type: application/json`
- `X-Correlation-Id` (optional): Trace ID
- `X-Message-Id` (optional): Business message ID

**Request Body:**
```json
{
  "message": "{1:F01...}{2:I103...}{4:
:20:REF123
...-}",
  "sourceType": "MT103",
  "targetType": "pacs.008.001.08",
  "messageId": "optional-business-id"
}
```

**Response:**
```json
{
  "correlationId": "uuid",
  "output": "<?xml version="1.0"...",
  "sourceType": "MT103",
  "targetType": "pacs.008.001.08",
  "processingTimeMs": 15,
  "success": true,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### POST /api/v1/translate/detect
Detects message format and type.

### GET /api/v1/admin/routes
Returns supported message type routes.

### GET /api/v1/admin/audit/{correlationId}
Returns audit record for a translation.

### GET /actuator/health
Health check endpoint.

### GET /actuator/metrics
Prometheus metrics endpoint.
