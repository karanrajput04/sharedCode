# Swift Translator - Deployment Guide

## Prerequisites

- Java 21
- Gradle 8.5+
- Docker (optional)
- Kubernetes 1.28+ (optional)

## Local Development

```bash
# Clone repository
git clone <repo-url>
cd swift-translator

# Build
./gradlew clean build

# Run tests
./gradlew test

# Run application
./gradlew bootRun
```

## Docker Deployment

```bash
# Build image
docker build -t swift-translator:1.0.0 .

# Run container
docker run -p 8080:8080   -e SPRING_PROFILES_ACTIVE=prod   swift-translator:1.0.0
```

## Kubernetes Deployment

```bash
# Create namespace
kubectl create namespace swift-translator

# Deploy
kubectl apply -f k8s/

# Verify
kubectl get pods -n swift-translator
kubectl get svc -n swift-translator
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| SPRING_PROFILES_ACTIVE | Active profile | dev |
| DATABASE_URL | PostgreSQL URL | jdbc:h2:mem:... |
| KAFKA_BOOTSTRAP_SERVERS | Kafka brokers | localhost:9092 |
| REDIS_HOST | Redis host | localhost |
| LOG_LEVEL | Logging level | INFO |

### Profiles

- **dev**: H2 database, debug logging
- **prod**: PostgreSQL, structured JSON logging
