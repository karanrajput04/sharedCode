# Swift Translator - Architecture Documentation

## Overview

The Swift Translator is an enterprise-grade application for bidirectional translation between SWIFT MT (legacy text format) and MX (ISO 20022 XML format) messages.

## Architecture Patterns

### Hexagonal (Clean) Architecture
The application follows hexagonal architecture principles:
- **Domain Layer**: Core business logic, canonical model, exceptions
- **Application Layer**: Use cases, ports, services
- **Infrastructure Layer**: Adapters, controllers, persistence

### Pipeline Pattern
Message processing follows a pipeline:
```
Input -> Detection -> Parsing -> Validation -> Mapping -> 
Transformation -> Rule Engine -> Validation -> Serialization -> Output
```

## Key Components

### Domain Model
- **CanonicalMessage**: Universal intermediate representation
- **MessageType**: Immutable value object for message type codes
- **MessageMetadata**: Correlation and tracking information

### Engine Components
- **ParserFactory**: Strategy pattern for format-specific parsers
- **SerializerFactory**: Strategy pattern for format-specific serializers
- **MappingEngine**: Configuration-driven field mapping
- **TransformationEngine**: Built-in and custom function execution
- **RuleEngine**: Business rule evaluation with SpEL
- **ValidationEngine**: Multi-stage validation pipeline

## Performance Characteristics

| Metric | Target | Implementation |
|--------|--------|---------------|
| Throughput | 10,000 msg/sec | Thread pools, parallel streams |
| Latency (p99) | <50ms | Caching, optimized parsers |
| Memory | <2GB per pod | Object pooling, streaming |

## Security

- Field-level masking for sensitive data
- Correlation ID tracing
- Audit logging
- Input validation

## Deployment

### Docker
```bash
docker build -t swift-translator:1.0.0 .
docker run -p 8080:8080 swift-translator:1.0.0
```

### Kubernetes
```bash
kubectl apply -f k8s/
```

### Docker Compose
```bash
docker-compose up -d
```
